#import <UIKit/UIKit.h>

/// 起動中のゲームの一覧。タップして接続する。
@interface MSGameListViewController : UITableViewController
@end

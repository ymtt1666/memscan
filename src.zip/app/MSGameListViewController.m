#import "MSGameListViewController.h"
#import "MSClient.h"
#import "MSPanelViewController.h"

/* ゲームのアプリを開くための非公開API(脱獄環境では使える) */
@interface LSApplicationWorkspace : NSObject
+ (instancetype)defaultWorkspace;
- (BOOL)openApplicationWithBundleID:(NSString *)bundleID;
@end

@implementation MSGameListViewController {
    NSArray<NSDictionary *> *_apps;
    NSTimer *_timer;
    NSString *_error;
    BOOL _showingPanel;
    BOOL _didAutoOpen;
}

- (instancetype)init {
    return [super initWithStyle:UITableViewStyleInsetGrouped];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"接続するゲーム";
    self.navigationItem.rightBarButtonItem =
        [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemRefresh target:self action:@selector(reload)];

    UILabel *foot = [UILabel new];
    foot.numberOfLines = 0;
    foot.font = [UIFont systemFontOfSize:13];
    foot.textColor = UIColor.secondaryLabelColor;
    foot.text = @"先にゲームを起動してから、ここに戻ってタップします。起動していないゲームは一覧に出ません。\n\nオンラインゲームでは使わないでください。読むだけでもアカウント停止の危険があります。";
    CGFloat w = UIScreen.mainScreen.bounds.size.width - 40;
    CGSize sz = [foot sizeThatFits:CGSizeMake(w, CGFLOAT_MAX)];
    UIView *wrap = [[UIView alloc] initWithFrame:CGRectMake(0, 0, w + 40, sz.height + 24)];
    foot.frame = CGRectMake(20, 8, w, sz.height);
    [wrap addSubview:foot];
    self.tableView.tableFooterView = wrap;
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    _showingPanel = NO;
    [self reload];
    __weak typeof(self) ws = self;
    _timer = [NSTimer scheduledTimerWithTimeInterval:2.0 repeats:YES block:^(NSTimer *t) { [ws reload]; }];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [_timer invalidate];
    _timer = nil;
}

- (void)reload {
    __weak typeof(self) ws = self;
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        NSString *err = nil;
        NSArray<NSString *> *lines = MSRequest(@"APPS", &err);
        NSString *serr = nil;
        NSArray<NSString *> *st = lines ? MSRequest(@"STATUS", &serr) : nil;
        dispatch_async(dispatch_get_main_queue(), ^{
            __strong typeof(ws) s = ws;
            if (!s) return;
            NSMutableArray *apps = [NSMutableArray array];
            for (NSString *ln in lines ?: @[]) {
                NSArray *f = [ln componentsSeparatedByString:@"\t"];
                if (f.count >= 3) [apps addObject:@{@"pid": f[0], @"bid": f[1], @"name": f[2]}];
            }
            s->_apps = apps;
            s->_error = lines ? nil : err;
            [s.tableView reloadData];
            [s updateEmptyState];

            /* すでに接続中なら、そのまま操作画面を開く */
            BOOL first = !s->_didAutoOpen;
            s->_didAutoOpen = YES;
            if (first && st.count && !s->_showingPanel) {
                NSArray *f = [st[0] componentsSeparatedByString:@"\t"];
                if (f.count >= 2 && [f[0] integerValue] > 0) {
                    NSString *name = f[1];
                    for (NSDictionary *a in apps) if ([a[@"bid"] isEqualToString:f[1]]) name = a[@"name"];
                    [s showPanelForName:name bundle:f[1]];
                }
            }
        });
    });
}

- (void)updateEmptyState {
    if (_apps.count) { self.tableView.backgroundView = nil; return; }
    UILabel *l = [UILabel new];
    l.numberOfLines = 0;
    l.textAlignment = NSTextAlignmentCenter;
    l.textColor = _error ? UIColor.systemRedColor : UIColor.secondaryLabelColor;
    l.font = [UIFont systemFontOfSize:15];
    l.text = _error ?: @"起動中のゲームがありません。\nゲームを開いてから、ここに戻ってください。";
    self.tableView.backgroundView = l;
}

#pragma mark - 一覧

- (NSInteger)tableView:(UITableView *)tv numberOfRowsInSection:(NSInteger)section {
    return (NSInteger)_apps.count;
}

- (NSString *)tableView:(UITableView *)tv titleForHeaderInSection:(NSInteger)section {
    return _apps.count ? @"起動中" : nil;
}

- (UITableViewCell *)tableView:(UITableView *)tv cellForRowAtIndexPath:(NSIndexPath *)ip {
    UITableViewCell *c = [tv dequeueReusableCellWithIdentifier:@"app"];
    if (!c) c = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"app"];
    NSDictionary *a = _apps[(NSUInteger)ip.row];
    c.textLabel.text = a[@"name"];
    c.textLabel.font = [UIFont systemFontOfSize:17 weight:UIFontWeightMedium];
    c.detailTextLabel.text = @"タップして接続";
    c.detailTextLabel.textColor = UIColor.secondaryLabelColor;
    c.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return c;
}

- (CGFloat)tableView:(UITableView *)tv heightForRowAtIndexPath:(NSIndexPath *)ip {
    return 64;
}

- (void)tableView:(UITableView *)tv didSelectRowAtIndexPath:(NSIndexPath *)ip {
    [tv deselectRowAtIndexPath:ip animated:YES];
    NSDictionary *a = _apps[(NSUInteger)ip.row];
    UIAlertController *al = [UIAlertController
        alertControllerWithTitle:[NSString stringWithFormat:@"%@ に接続しますか？", a[@"name"]]
                         message:@"オンラインゲームでは使わないでください。読むだけでも BAN の危険があります。"
                  preferredStyle:UIAlertControllerStyleAlert];
    __weak typeof(self) ws = self;
    [al addAction:[UIAlertAction actionWithTitle:@"オフラインで遊ぶゲームです。接続する"
                                           style:UIAlertActionStyleDefault
                                         handler:^(UIAlertAction *x) { [ws attach:a]; }]];
    [al addAction:[UIAlertAction actionWithTitle:@"やめる" style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:al animated:YES completion:nil];
}

#pragma mark - 接続

- (void)attach:(NSDictionary *)a {
    NSString *cmd = [NSString stringWithFormat:@"ATTACH %@ %@", a[@"pid"], a[@"bid"]];
    __weak typeof(self) ws = self;
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        NSString *err = nil;
        NSArray *r = MSRequest(cmd, &err);
        dispatch_async(dispatch_get_main_queue(), ^{
            __strong typeof(ws) s = ws;
            if (!r) {
                UIAlertController *e = [UIAlertController alertControllerWithTitle:@"接続できませんでした"
                                                                           message:err ?: @"もう一度お試しください"
                                                                    preferredStyle:UIAlertControllerStyleAlert];
                [e addAction:[UIAlertAction actionWithTitle:@"閉じる" style:UIAlertActionStyleCancel handler:nil]];
                [s presentViewController:e animated:YES completion:nil];
                return;
            }
            [s showPanelForName:a[@"name"] bundle:a[@"bid"]];
        });
    });
}

- (void)showPanelForName:(NSString *)name bundle:(NSString *)bid {
    if (_showingPanel) return;
    _showingPanel = YES;
    MSPanelViewController *p = [MSPanelViewController new];
    p.gameName = name;
    p.title = name;
    __weak typeof(self) ws = self;
    p.onDisconnect = ^{
        __strong typeof(ws) s = ws;
        if (!s) return;
        s->_showingPanel = NO;
        [s.navigationController popToRootViewControllerAnimated:YES];
    };
    p.onReturnToGame = ^{
        Class cls = NSClassFromString(@"LSApplicationWorkspace");
        if (cls) [(LSApplicationWorkspace *)[cls defaultWorkspace] openApplicationWithBundleID:bid];
    };
    p.navigationItem.largeTitleDisplayMode = UINavigationItemLargeTitleDisplayModeNever;
    [self.navigationController pushViewController:p animated:YES];
}

@end

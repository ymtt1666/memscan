#ifndef MS_CONFIG_H
#define MS_CONFIG_H

/* Dopamine (rootless) では /var/jb の下に置く */
#ifndef MS_SOCK_PATH
#define MS_SOCK_PATH "/var/jb/var/run/memscan.sock"
#endif
#ifndef MS_DATA_DIR
#define MS_DATA_DIR "/var/jb/var/mobile/Library/MemScan"
#endif
#define MS_SELF_BUNDLE "com.memscan.app"

#endif

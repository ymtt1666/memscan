#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/// 検索・絞り込み・書き換え・固定・保存・緊急停止をまとめた画面。
/// アプリ本体と、ゲームの上に出る丸ボタン(SpringBoard)の両方で使う。
@interface MSPanelViewController : UIViewController

@property (nonatomic, copy) NSString *gameName;
/// 右上の「×」。設定されているときだけ表示する。
@property (nonatomic, copy, nullable) void (^onClose)(void);
/// 接続を切った、またはゲームが終了したとき。
@property (nonatomic, copy, nullable) void (^onDisconnect)(void);
/// 「ゲームに戻る」。設定されているときだけボタンを表示する。
@property (nonatomic, copy, nullable) void (^onReturnToGame)(void);

- (void)reloadAll;

@end

NS_ASSUME_NONNULL_END

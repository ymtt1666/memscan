#import "MSClient.h"
#import "ms_config.h"
#import <sys/socket.h>
#import <sys/un.h>
#import <unistd.h>

static NSString *const kUnreachable = @"裏方プログラム(memscand)につながりません。再起動後は Dopamine で脱獄し直してください";

NSArray<NSString *> *MSRequest(NSString *command, NSString **error) {
    int fd = socket(AF_UNIX, SOCK_STREAM, 0);
    if (fd < 0) { if (error) *error = kUnreachable; return nil; }
    int one = 1;
    setsockopt(fd, SOL_SOCKET, SO_NOSIGPIPE, &one, sizeof one);
    struct timeval tv = {.tv_sec = 120, .tv_usec = 0};
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof tv);

    struct sockaddr_un sa;
    memset(&sa, 0, sizeof sa);
    sa.sun_family = AF_UNIX;
    strlcpy(sa.sun_path, MS_SOCK_PATH, sizeof sa.sun_path);
    if (connect(fd, (struct sockaddr *)&sa, sizeof sa) != 0) {
        close(fd);
        if (error) *error = kUnreachable;
        return nil;
    }

    NSString *line = [command stringByAppendingString:@"\n"];
    const char *out = line.UTF8String;
    size_t left = strlen(out);
    while (left > 0) {
        ssize_t w = write(fd, out, left);
        if (w <= 0) { close(fd); if (error) *error = kUnreachable; return nil; }
        out += w;
        left -= (size_t)w;
    }

    NSMutableData *buf = [NSMutableData data];
    uint8_t chunk[16384];
    for (;;) {
        ssize_t r = read(fd, chunk, sizeof chunk);
        if (r <= 0) break;
        [buf appendBytes:chunk length:(NSUInteger)r];
        if (buf.length >= 2) {
            const uint8_t *b = buf.bytes;
            NSUInteger n = buf.length;
            if (b[n - 1] == '\n' && b[n - 2] == '.' && (n == 2 || b[n - 3] == '\n')) break;
        }
    }
    close(fd);

    NSString *text = [[NSString alloc] initWithData:buf encoding:NSUTF8StringEncoding];
    if (!text.length) { if (error) *error = @"応答がありませんでした"; return nil; }
    NSMutableArray<NSString *> *lines = [[text componentsSeparatedByString:@"\n"] mutableCopy];
    while (lines.count && ([lines.lastObject isEqualToString:@""] || [lines.lastObject isEqualToString:@"."]))
        [lines removeLastObject];
    if (!lines.count) { if (error) *error = @"応答が空でした"; return nil; }

    NSString *head = lines.firstObject;
    [lines removeObjectAtIndex:0];
    if ([head hasPrefix:@"ERR"]) {
        NSString *m = head.length > 4 ? [head substringFromIndex:4] : @"失敗しました";
        if (error) *error = m;
        return nil;
    }
    return lines;
}

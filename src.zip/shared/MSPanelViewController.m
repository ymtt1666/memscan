#import "MSPanelViewController.h"
#import "MSClient.h"

static const NSInteger kMaxRows = 20;

@interface MSPanelViewController () <UITextFieldDelegate>
@end

@implementation MSPanelViewController {
    UIView *_dot;
    UILabel *_title;
    UIButton *_closeBtn;
    UILabel *_msg;
    UISegmentedControl *_typeSeg;
    UITextField *_valueField;
    UIButton *_firstBtn;
    UIButton *_nextBtn;
    UIStackView *_modeBox;
    UILabel *_countLabel;
    UIButton *_resetBtn;
    UILabel *_resultsHint;
    UIStackView *_resultsStack;
    UIStackView *_cheatsStack;
    UIButton *_returnBtn;
    NSTimer *_timer;
    BOOL _hasSearch;
    NSInteger _count;
    NSString *_scanType;
}

#pragma mark - 部品づくり

static NSString *TypeForIndex(NSInteger i) {
    NSArray *t = @[@"i32", @"f32", @"i64", @"f64"];
    return t[(NSUInteger)MAX(0, MIN(i, 3))];
}

- (UILabel *)label:(NSString *)text size:(CGFloat)size weight:(UIFontWeight)w color:(UIColor *)c {
    UILabel *l = [UILabel new];
    l.text = text;
    l.font = [UIFont systemFontOfSize:size weight:w];
    l.textColor = c;
    l.numberOfLines = 0;
    return l;
}

- (UIButton *)button:(NSString *)title kind:(NSInteger)kind action:(void (^)(void))action {
    UIButtonConfiguration *cfg;
    switch (kind) {
        case 0: cfg = [UIButtonConfiguration filledButtonConfiguration]; break;
        case 1: cfg = [UIButtonConfiguration tintedButtonConfiguration]; break;
        case 2: cfg = [UIButtonConfiguration plainButtonConfiguration]; break;
        default:
            cfg = [UIButtonConfiguration tintedButtonConfiguration];
            cfg.baseForegroundColor = UIColor.systemRedColor;
            cfg.baseBackgroundColor = UIColor.systemRedColor;
            break;
    }
    cfg.title = title;
    cfg.cornerStyle = UIButtonConfigurationCornerStyleMedium;
    cfg.titleTextAttributesTransformer = ^NSDictionary<NSAttributedStringKey, id> *(NSDictionary<NSAttributedStringKey, id> *attrs) {
        NSMutableDictionary *d = [attrs mutableCopy];
        d[NSFontAttributeName] = [UIFont systemFontOfSize:15 weight:UIFontWeightSemibold];
        return d;
    };
    UIButton *b = [UIButton buttonWithConfiguration:cfg
                                      primaryAction:[UIAction actionWithTitle:@"" image:nil identifier:nil handler:^(__kindof UIAction *a) { action(); }]];
    [b.heightAnchor constraintGreaterThanOrEqualToConstant:44].active = YES;
    return b;
}

- (UIStackView *)stack:(UILayoutConstraintAxis)axis spacing:(CGFloat)s views:(NSArray<UIView *> *)v {
    UIStackView *st = [[UIStackView alloc] initWithArrangedSubviews:v];
    st.axis = axis;
    st.spacing = s;
    return st;
}

- (UIView *)card:(NSArray<UIView *> *)views {
    UIStackView *st = [self stack:UILayoutConstraintAxisVertical spacing:10 views:views];
    st.translatesAutoresizingMaskIntoConstraints = NO;
    UIView *card = [UIView new];
    card.backgroundColor = UIColor.secondarySystemBackgroundColor;
    card.layer.cornerRadius = 12;
    [card addSubview:st];
    [NSLayoutConstraint activateConstraints:@[
        [st.topAnchor constraintEqualToAnchor:card.topAnchor constant:12],
        [st.bottomAnchor constraintEqualToAnchor:card.bottomAnchor constant:-12],
        [st.leadingAnchor constraintEqualToAnchor:card.leadingAnchor constant:12],
        [st.trailingAnchor constraintEqualToAnchor:card.trailingAnchor constant:-12],
    ]];
    return card;
}

- (UITextField *)field:(NSString *)placeholder size:(CGFloat)size {
    UITextField *f = [UITextField new];
    f.placeholder = placeholder;
    f.font = [UIFont monospacedDigitSystemFontOfSize:size weight:UIFontWeightRegular];
    f.borderStyle = UITextBorderStyleRoundedRect;
    f.keyboardType = UIKeyboardTypeNumbersAndPunctuation;
    f.returnKeyType = UIReturnKeyDone;
    f.autocorrectionType = UITextAutocorrectionTypeNo;
    f.clearButtonMode = UITextFieldViewModeWhileEditing;
    f.delegate = self;
    [f.heightAnchor constraintGreaterThanOrEqualToConstant:44].active = YES;
    return f;
}

- (BOOL)textFieldShouldReturn:(UITextField *)tf {
    [tf resignFirstResponder];
    return YES;
}

#pragma mark - 画面

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = UIColor.systemBackgroundColor;

    /* 見出し */
    _dot = [UIView new];
    _dot.backgroundColor = UIColor.systemGreenColor;
    _dot.layer.cornerRadius = 5;
    [_dot.widthAnchor constraintEqualToConstant:10].active = YES;
    [_dot.heightAnchor constraintEqualToConstant:10].active = YES;
    _title = [self label:@"" size:16 weight:UIFontWeightSemibold color:UIColor.labelColor];
    _title.numberOfLines = 1;
    __weak typeof(self) ws = self;
    _closeBtn = [self button:@"×" kind:2 action:^{ if (ws.onClose) ws.onClose(); }];
    UIView *spacer = [UIView new];
    [spacer setContentHuggingPriority:(UILayoutPriority)1 forAxis:UILayoutConstraintAxisHorizontal];
    UIStackView *head = [self stack:UILayoutConstraintAxisHorizontal spacing:8 views:@[_dot, _title, spacer, _closeBtn]];
    head.alignment = UIStackViewAlignmentCenter;

    _msg = [self label:@"" size:13 weight:UIFontWeightRegular color:UIColor.secondaryLabelColor];
    _msg.hidden = YES;

    /* 検索 */
    UILabel *tip = [self label:@"ゲーム画面に出ている数値を入れて検索 → ゲームで数値を変える → 新しい数値で絞り込み、を繰り返します"
                          size:13 weight:UIFontWeightRegular color:UIColor.secondaryLabelColor];
    _typeSeg = [[UISegmentedControl alloc] initWithItems:@[@"整数", @"小数", @"大きい整数", @"倍精度小数"]];
    _typeSeg.selectedSegmentIndex = 0;
    [_typeSeg addAction:[UIAction actionWithTitle:@"" image:nil identifier:nil handler:^(__kindof UIAction *a) {
        [ws doReset];
    }] forControlEvents:UIControlEventValueChanged];
    _valueField = [self field:@"今の数値 (例: 1500)" size:22];
    _firstBtn = [self button:@"検索する" kind:0 action:^{ [ws doFirst]; }];
    _nextBtn = [self button:@"この数値で絞り込む" kind:1 action:^{ [ws doNext:@"eq" value:nil]; }];

    UILabel *modeTip = [self label:@"数値がわからないとき" size:13 weight:UIFontWeightRegular color:UIColor.secondaryLabelColor];
    UIStackView *row1 = [self stack:UILayoutConstraintAxisHorizontal spacing:8 views:@[
        [self button:@"増えた" kind:1 action:^{ [ws doNext:@"inc" value:nil]; }],
        [self button:@"減った" kind:1 action:^{ [ws doNext:@"dec" value:nil]; }]]];
    UIStackView *row2 = [self stack:UILayoutConstraintAxisHorizontal spacing:8 views:@[
        [self button:@"変わった" kind:1 action:^{ [ws doNext:@"chg" value:nil]; }],
        [self button:@"変わらない" kind:1 action:^{ [ws doNext:@"same" value:nil]; }]]];
    row1.distribution = row2.distribution = UIStackViewDistributionFillEqually;
    _modeBox = [self stack:UILayoutConstraintAxisVertical spacing:8 views:@[modeTip, row1, row2]];

    _countLabel = [self label:@"" size:15 weight:UIFontWeightMedium color:UIColor.labelColor];
    _resetBtn = [self button:@"最初から" kind:2 action:^{ [ws doReset]; }];
    UIStackView *countRow = [self stack:UILayoutConstraintAxisHorizontal spacing:8 views:@[_countLabel, _resetBtn]];
    countRow.alignment = UIStackViewAlignmentCenter;

    UIView *searchCard = [self card:@[tip, _typeSeg, _valueField, _firstBtn, _nextBtn, _modeBox, countRow]];

    /* 候補 */
    _resultsHint = [self label:@"" size:13 weight:UIFontWeightRegular color:UIColor.secondaryLabelColor];
    _resultsStack = [self stack:UILayoutConstraintAxisVertical spacing:10 views:@[]];
    UIView *resultsCard = [self card:@[
        [self label:@"候補" size:15 weight:UIFontWeightSemibold color:UIColor.labelColor], _resultsHint, _resultsStack]];

    /* 保存したチート */
    _cheatsStack = [self stack:UILayoutConstraintAxisVertical spacing:8 views:@[]];
    UIView *cheatsCard = [self card:@[
        [self label:@"保存したチート" size:15 weight:UIFontWeightSemibold color:UIColor.labelColor], _cheatsStack]];

    /* 下のボタン */
    UIStackView *safeRow = [self stack:UILayoutConstraintAxisHorizontal spacing:8 views:@[
        [self button:@"元に戻す" kind:1 action:^{ [ws doUndo]; }],
        [self button:@"緊急停止" kind:3 action:^{ [ws doStopAll]; }]]];
    safeRow.distribution = UIStackViewDistributionFillEqually;
    _returnBtn = [self button:@"ゲームに戻る" kind:0 action:^{ if (ws.onReturnToGame) ws.onReturnToGame(); }];
    UIButton *disc = [self button:@"接続を切る" kind:2 action:^{ [ws doDisconnect]; }];

    UIStackView *content = [self stack:UILayoutConstraintAxisVertical spacing:12 views:@[
        head, _msg, searchCard, resultsCard, cheatsCard, safeRow, _returnBtn, disc]];
    content.translatesAutoresizingMaskIntoConstraints = NO;

    UIScrollView *sv = [UIScrollView new];
    sv.translatesAutoresizingMaskIntoConstraints = NO;
    sv.keyboardDismissMode = UIScrollViewKeyboardDismissModeInteractive;
    sv.alwaysBounceVertical = YES;
    [self.view addSubview:sv];
    [sv addSubview:content];
    UILayoutGuide *safe = self.view.safeAreaLayoutGuide;
    [NSLayoutConstraint activateConstraints:@[
        [sv.topAnchor constraintEqualToAnchor:safe.topAnchor],
        [sv.bottomAnchor constraintEqualToAnchor:self.view.bottomAnchor],
        [sv.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor],
        [sv.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor],
        [content.topAnchor constraintEqualToAnchor:sv.contentLayoutGuide.topAnchor constant:12],
        [content.bottomAnchor constraintEqualToAnchor:sv.contentLayoutGuide.bottomAnchor constant:-24],
        [content.leadingAnchor constraintEqualToAnchor:sv.frameLayoutGuide.leadingAnchor constant:14],
        [content.trailingAnchor constraintEqualToAnchor:sv.frameLayoutGuide.trailingAnchor constant:-14],
    ]];

    /* 2秒ごとに状態を確かめる(ゲームの終了を知るため) */
    _timer = [NSTimer scheduledTimerWithTimeInterval:2.0 repeats:YES block:^(NSTimer *t) {
        __strong typeof(ws) s = ws;
        if (!s) { [t invalidate]; return; }
        if (s.isViewLoaded && s.view.window && !s.view.window.hidden) [s refreshStatus];
    }];
    [self updateSearchState];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    _title.text = self.gameName.length ? [NSString stringWithFormat:@"%@ に接続中", self.gameName] : @"接続中";
    _closeBtn.hidden = (self.onClose == nil);
    _returnBtn.hidden = (self.onReturnToGame == nil);
    [self reloadAll];
}

- (void)dealloc {
    [_timer invalidate];
}

#pragma mark - 表示の更新

- (void)say:(NSString *)text error:(BOOL)isError {
    _msg.text = text;
    _msg.textColor = isError ? UIColor.systemRedColor : UIColor.systemGreenColor;
    _msg.hidden = (text.length == 0);
}

- (void)updateSearchState {
    _nextBtn.hidden = !_hasSearch;
    _modeBox.hidden = !_hasSearch;
    _resetBtn.hidden = !_hasSearch;
    _countLabel.hidden = !_hasSearch;
    UIButtonConfiguration *fc = _firstBtn.configuration;
    fc.title = _hasSearch ? @"新しく検索する" : @"検索する";
    _firstBtn.configuration = fc;
    _countLabel.text = [NSString stringWithFormat:@"候補: %ld 件", (long)_count];
}

- (void)run:(NSString *)cmd done:(void (^)(NSArray<NSString *> *, NSString *))done {
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        NSString *err = nil;
        NSArray<NSString *> *lines = MSRequest(cmd, &err);
        dispatch_async(dispatch_get_main_queue(), ^{ done(lines, err); });
    });
}

- (void)reloadAll {
    [self refreshStatus];
    [self reloadResults];
    [self reloadCheats];
}

- (void)refreshStatus {
    __weak typeof(self) ws = self;
    [self run:@"STATUS" done:^(NSArray<NSString *> *lines, NSString *err) {
        __strong typeof(ws) s = ws;
        if (!s || !lines.count) return;
        NSArray *f = [lines[0] componentsSeparatedByString:@"\t"];
        if (f.count < 6) return;
        if ([f[0] integerValue] == 0) {
            [s say:@"ゲームが終了したため、接続が切れました" error:YES];
            if (s.onDisconnect) s.onDisconnect();
            return;
        }
        s->_count = [f[3] integerValue];
        if (s->_count > 0 && !s->_hasSearch) {
            /* 画面を開き直したときも、続きから絞り込めるようにする */
            NSArray *types = @[@"i32", @"f32", @"i64", @"f64"];
            NSUInteger ti = [types indexOfObject:f[2]];
            if (ti != NSNotFound) {
                s->_hasSearch = YES;
                s->_scanType = f[2];
                s->_typeSeg.selectedSegmentIndex = (NSInteger)ti;
                [s reloadResults];
            }
        }
        if (s->_hasSearch) [s updateSearchState];
    }];
}

#pragma mark - 検索

- (NSString *)cleanValue {
    NSString *v = [_valueField.text stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceCharacterSet];
    return v;
}

- (void)doFirst {
    [_valueField resignFirstResponder];
    NSString *v = [self cleanValue];
    if (!v.length || [v rangeOfCharacterFromSet:NSCharacterSet.whitespaceCharacterSet].location != NSNotFound) {
        [self say:@"数値を入力してください" error:YES];
        return;
    }
    [self say:@"検索中…" error:NO];
    NSString *cmd = [NSString stringWithFormat:@"FIRST %@ %@", TypeForIndex(_typeSeg.selectedSegmentIndex), v];
    __weak typeof(self) ws = self;
    [self run:cmd done:^(NSArray<NSString *> *lines, NSString *err) {
        __strong typeof(ws) s = ws;
        if (!s) return;
        if (!lines) { [s say:err ?: @"失敗しました" error:YES]; return; }
        s->_hasSearch = YES;
        s->_scanType = TypeForIndex(s->_typeSeg.selectedSegmentIndex);
        s->_count = [lines.firstObject integerValue];
        [s updateSearchState];
        [s say:(s->_count == 0 ? @"見つかりませんでした。数値や種類(整数/小数)を変えてみてください"
                               : @"ゲームで数値を変えてから、新しい数値で絞り込んでください") error:(s->_count == 0)];
        [s reloadResults];
    }];
}

- (void)doNext:(NSString *)mode value:(NSString *)value {
    [_valueField resignFirstResponder];
    NSString *cmd = [NSString stringWithFormat:@"NEXT %@", mode];
    if ([mode isEqualToString:@"eq"]) {
        NSString *v = [self cleanValue];
        if (!v.length || [v rangeOfCharacterFromSet:NSCharacterSet.whitespaceCharacterSet].location != NSNotFound) {
            [self say:@"新しい数値を入力してください" error:YES];
            return;
        }
        cmd = [cmd stringByAppendingFormat:@" %@", v];
    }
    [self say:@"絞り込み中…" error:NO];
    __weak typeof(self) ws = self;
    [self run:cmd done:^(NSArray<NSString *> *lines, NSString *err) {
        __strong typeof(ws) s = ws;
        if (!s) return;
        if (!lines) { [s say:err ?: @"失敗しました" error:YES]; return; }
        s->_count = [lines.firstObject integerValue];
        [s updateSearchState];
        if (s->_count == 0) [s say:@"なくなりました。「最初から」でやり直してください" error:YES];
        else if (s->_count <= kMaxRows) [s say:@"候補が絞れました。下の候補で書き換えてみてください" error:NO];
        else [s say:@"まだ多いので、ゲームで数値を変えて、もう一度絞り込んでください" error:NO];
        [s reloadResults];
    }];
}

- (void)doReset {
    __weak typeof(self) ws = self;
    [self run:@"RESET" done:^(NSArray<NSString *> *lines, NSString *err) {
        __strong typeof(ws) s = ws;
        if (!s) return;
        s->_hasSearch = NO;
        s->_scanType = nil;
        s->_count = 0;
        [s updateSearchState];
        [s say:@"" error:NO];
        [s reloadResults];
    }];
}

#pragma mark - 候補

- (void)clearStack:(UIStackView *)st {
    for (UIView *v in st.arrangedSubviews) { [st removeArrangedSubview:v]; [v removeFromSuperview]; }
}

- (void)reloadResults {
    __weak typeof(self) ws = self;
    [self run:[NSString stringWithFormat:@"RESULTS 0 %ld", (long)kMaxRows] done:^(NSArray<NSString *> *lines, NSString *err) {
        __strong typeof(ws) s = ws;
        if (!s) return;
        [s clearStack:s->_resultsStack];
        NSString *type = s->_scanType ?: TypeForIndex(s->_typeSeg.selectedSegmentIndex);
        for (NSString *ln in lines ?: @[]) {
            NSArray *f = [ln componentsSeparatedByString:@"\t"];
            if (f.count < 4) continue;
            [s->_resultsStack addArrangedSubview:[s rowForAddr:f[0] value:f[1] frozen:[f[3] boolValue] type:type]];
        }
        BOOL empty = (s->_resultsStack.arrangedSubviews.count == 0);
        if (empty) s->_resultsHint.text = s->_hasSearch ? @"候補はありません" : @"検索すると、ここに候補が出ます";
        else if (s->_count > kMaxRows) s->_resultsHint.text = [NSString stringWithFormat:@"先頭の %ld 件だけ表示しています。絞り込むと減ります", (long)kMaxRows];
        else s->_resultsHint.text = @"ゲームの数値が変わるものを選んでください";
    }];
}

- (UIView *)rowForAddr:(NSString *)addr value:(NSString *)value frozen:(BOOL)frozen type:(NSString *)type {
    __weak typeof(self) ws = self;
    NSString *tail = addr.length > 6 ? [addr substringFromIndex:addr.length - 6] : addr;
    UILabel *l = [self label:[NSString stringWithFormat:@"%@　(…%@)", value, tail] size:17 weight:UIFontWeightMedium color:UIColor.labelColor];

    UITextField *nf = [self field:@"新しい値" size:16];
    nf.text = value;
    UISwitch *sw = [UISwitch new];
    sw.on = frozen;
    UILabel *swl = [self label:@"固定" size:13 weight:UIFontWeightRegular color:UIColor.secondaryLabelColor];
    swl.numberOfLines = 1;
    UIStackView *swBox = [self stack:UILayoutConstraintAxisVertical spacing:2 views:@[sw, swl]];
    swBox.alignment = UIStackViewAlignmentCenter;

    UIView *nameRow = nil;
    UITextField *nameField = [self field:@"名前 (例: コイン)" size:16];
    nameField.keyboardType = UIKeyboardTypeDefault;
    nameField.autocorrectionType = UITextAutocorrectionTypeNo;

    UIButton *set = [self button:@"書換" kind:0 action:^{
        NSString *v = [nf.text stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceCharacterSet];
        if (!v.length) { [ws say:@"値を入力してください" error:YES]; return; }
        [nf resignFirstResponder];
        NSString *cmd = [NSString stringWithFormat:@"SET %@ %@ %@", addr, type, v];
        [ws run:cmd done:^(NSArray<NSString *> *lines, NSString *err) {
            if (!lines) { [ws say:err ?: @"失敗しました" error:YES]; return; }
            [ws say:@"書き換えました。ゲーム画面で確かめてください" error:NO];
        }];
    }];

    __weak UISwitch *wsw = sw;
    [sw addAction:[UIAction actionWithTitle:@"" image:nil identifier:nil handler:^(__kindof UIAction *a) {
        UISwitch *sws = wsw;
        if (!sws) return;
        NSString *v = [nf.text stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceCharacterSet];
        NSString *cmd = sws.on ? [NSString stringWithFormat:@"FREEZE %@ %@ %@", addr, type, v]
                               : [NSString stringWithFormat:@"UNFREEZE %@", addr];
        [ws run:cmd done:^(NSArray<NSString *> *lines, NSString *err) {
            UISwitch *s2 = wsw;
            if (!lines) { s2.on = !s2.on; [ws say:err ?: @"失敗しました" error:YES]; return; }
            [ws say:(s2.on ? @"固定しました" : @"固定を止めました") error:NO];
        }];
    }] forControlEvents:UIControlEventValueChanged];

    UIButton *saveToggle = [self button:@"保存" kind:2 action:^{}];
    UIButton *doSave = [self button:@"保存する" kind:1 action:^{
        NSString *name = [nameField.text stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
        NSString *v = [nf.text stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceCharacterSet];
        if (!name.length) { [ws say:@"名前を入力してください" error:YES]; return; }
        if (!v.length) { [ws say:@"値を入力してください" error:YES]; return; }
        NSString *cmd = [NSString stringWithFormat:@"SAVE %@ %@ %@ %d %@", addr, type, v, sw.on ? 1 : 0, name];
        [nameField resignFirstResponder];
        [ws run:cmd done:^(NSArray<NSString *> *lines, NSString *err) {
            if (!lines) { [ws say:err ?: @"保存できませんでした" error:YES]; return; }
            BOOL stat = [lines.firstObject isEqualToString:@"static"];
            [ws say:(stat ? @"保存しました" : @"保存しました。ただし、ゲームを開き直すと場所が変わって使えない場合があります") error:NO];
            nameField.text = @"";
            [ws reloadCheats];
        }];
    }];
    nameRow = [self stack:UILayoutConstraintAxisHorizontal spacing:8 views:@[nameField, doSave]];
    nameRow.hidden = YES;
    [saveToggle addAction:[UIAction actionWithTitle:@"" image:nil identifier:nil handler:^(__kindof UIAction *a) {
        [UIView animateWithDuration:0.2 animations:^{ nameRow.hidden = !nameRow.hidden; }];
    }] forControlEvents:UIControlEventTouchUpInside];

    [nf setContentHuggingPriority:(UILayoutPriority)249 forAxis:UILayoutConstraintAxisHorizontal];
    UIStackView *line2 = [self stack:UILayoutConstraintAxisHorizontal spacing:8 views:@[nf, set, swBox, saveToggle]];
    line2.alignment = UIStackViewAlignmentCenter;

    UIStackView *row = [self stack:UILayoutConstraintAxisVertical spacing:6 views:@[l, line2, nameRow]];
    UIView *wrap = [UIView new];
    row.translatesAutoresizingMaskIntoConstraints = NO;
    [wrap addSubview:row];
    wrap.backgroundColor = UIColor.tertiarySystemBackgroundColor;
    wrap.layer.cornerRadius = 10;
    [NSLayoutConstraint activateConstraints:@[
        [row.topAnchor constraintEqualToAnchor:wrap.topAnchor constant:10],
        [row.bottomAnchor constraintEqualToAnchor:wrap.bottomAnchor constant:-10],
        [row.leadingAnchor constraintEqualToAnchor:wrap.leadingAnchor constant:10],
        [row.trailingAnchor constraintEqualToAnchor:wrap.trailingAnchor constant:-10],
    ]];
    return wrap;
}

#pragma mark - 保存したチート

- (void)reloadCheats {
    __weak typeof(self) ws = self;
    [self run:@"CHEATS" done:^(NSArray<NSString *> *lines, NSString *err) {
        __strong typeof(ws) s = ws;
        if (!s) return;
        [s clearStack:s->_cheatsStack];
        for (NSString *ln in lines ?: @[]) {
            NSArray *f = [ln componentsSeparatedByString:@"\t"];
            if (f.count < 7) continue;
            [s->_cheatsStack addArrangedSubview:[s cheatRow:f]];
        }
        if (s->_cheatsStack.arrangedSubviews.count == 0) {
            [s->_cheatsStack addArrangedSubview:[s label:@"まだありません。候補の「保存」から、名前を付けて残せます"
                                                    size:13 weight:UIFontWeightRegular color:UIColor.secondaryLabelColor]];
        }
    }];
}

- (UIView *)cheatRow:(NSArray *)f {
    /* idx, name, type, value, freeze, addr, active */
    __weak typeof(self) ws = self;
    NSString *idx = f[0], *name = f[1], *value = f[3], *addr = f[5];
    BOOL freeze = [f[4] boolValue], active = [f[6] boolValue];

    UILabel *n = [self label:name size:16 weight:UIFontWeightMedium color:UIColor.labelColor];
    UILabel *sub = [self label:[NSString stringWithFormat:@"%@ %@", value, freeze ? @"に固定" : @"に書き換え"]
                          size:12 weight:UIFontWeightRegular color:UIColor.secondaryLabelColor];
    UIStackView *text = [self stack:UILayoutConstraintAxisVertical spacing:2 views:@[n, sub]];

    UIView *control;
    if (freeze) {
        UISwitch *sw = [UISwitch new];
        sw.on = active;
        __weak UISwitch *wsw = sw;
        [sw addAction:[UIAction actionWithTitle:@"" image:nil identifier:nil handler:^(__kindof UIAction *a) {
            UISwitch *sws = wsw;
            if (!sws) return;
            NSString *cmd = sws.on ? [NSString stringWithFormat:@"APPLY %@", idx] : [NSString stringWithFormat:@"UNFREEZE %@", addr];
            [ws run:cmd done:^(NSArray<NSString *> *lines, NSString *err) {
                UISwitch *s2 = wsw;
                if (!lines) { s2.on = !s2.on; [ws say:err ?: @"失敗しました" error:YES]; return; }
                [ws say:(s2.on ? @"オンにしました" : @"オフにしました") error:NO];
            }];
        }] forControlEvents:UIControlEventValueChanged];
        control = sw;
    } else {
        control = [self button:@"実行" kind:1 action:^{
            [ws run:[NSString stringWithFormat:@"APPLY %@", idx] done:^(NSArray<NSString *> *lines, NSString *err) {
                [ws say:(lines ? @"書き換えました" : (err ?: @"失敗しました")) error:(lines == nil)];
            }];
        }];
    }
    UIButton *del = [self button:@"削除" kind:2 action:^{
        [ws run:[NSString stringWithFormat:@"DELCHEAT %@", idx] done:^(NSArray<NSString *> *lines, NSString *err) {
            [ws reloadCheats];
        }];
    }];
    UIStackView *row = [self stack:UILayoutConstraintAxisHorizontal spacing:8 views:@[text, control, del]];
    row.alignment = UIStackViewAlignmentCenter;
    return row;
}

#pragma mark - 下のボタン

- (void)doUndo {
    __weak typeof(self) ws = self;
    [self run:@"UNDO" done:^(NSArray<NSString *> *lines, NSString *err) {
        [ws say:(lines ? @"直前の書き換えを元に戻しました" : (err ?: @"失敗しました")) error:(lines == nil)];
        [ws reloadResults];
    }];
}

- (void)doStopAll {
    __weak typeof(self) ws = self;
    [self run:@"STOPALL" done:^(NSArray<NSString *> *lines, NSString *err) {
        [ws say:(lines ? @"すべての固定を止めました" : (err ?: @"失敗しました")) error:(lines == nil)];
        [ws reloadResults];
        [ws reloadCheats];
    }];
}

- (void)doDisconnect {
    __weak typeof(self) ws = self;
    [self run:@"DETACH" done:^(NSArray<NSString *> *lines, NSString *err) {
        __strong typeof(ws) s = ws;
        if (s && s.onDisconnect) s.onDisconnect();
    }];
}

@end

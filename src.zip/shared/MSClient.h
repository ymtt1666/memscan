#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/// デーモン(memscand)に命令を送る。応答の本文(1行ごとの文字列)を返す。
/// 失敗したら nil を返し、*error に理由を入れる。時間がかかるので、メインスレッドでは呼ばないこと。
NSArray<NSString *> *_Nullable MSRequest(NSString *command, NSString *_Nullable *_Nullable error);

NS_ASSUME_NONNULL_END

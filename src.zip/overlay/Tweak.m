/* SpringBoard に入って、ゲームの上に丸いボタンと操作パネルを出す部品。
 * 接続中のゲームがあるときだけボタンが出る。 */
#import <UIKit/UIKit.h>
#import "MSClient.h"
#import "MSPanelViewController.h"

static const CGFloat kBtn = 52;

#pragma mark - 状態

@interface MSOverlay : NSObject
+ (instancetype)shared;
- (void)start;
@end

@interface MSHostViewController : UIViewController
@property (nonatomic, strong) MSPanelViewController *panel;
- (void)layoutPanelForWindowSize:(CGSize)size angle:(CGFloat)angle visual:(CGSize)visual;
@end

@implementation MSHostViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = UIColor.clearColor;
    [self addChildViewController:self.panel];
    self.panel.view.layer.cornerRadius = 16;
    self.panel.view.clipsToBounds = YES;
    self.panel.view.layer.borderWidth = 0.5;
    self.panel.view.layer.borderColor = UIColor.separatorColor.CGColor;
    [self.view addSubview:self.panel.view];
    [self.panel didMoveToParentViewController:self];
}
- (void)layoutPanelForWindowSize:(CGSize)size angle:(CGFloat)angle visual:(CGSize)visual {
    UIView *v = self.panel.view;
    v.transform = CGAffineTransformIdentity;
    v.bounds = CGRectMake(0, 0, visual.width, visual.height);
    v.center = CGPointMake(size.width / 2, size.height / 2);
    v.transform = CGAffineTransformMakeRotation(angle);
}
@end

@implementation MSOverlay {
    UIWindow *_buttonWindow;
    UIWindow *_panelWindow;
    MSHostViewController *_host;
    MSPanelViewController *_panel;
    UIView *_btnView;
    NSTimer *_timer;
    BOOL _attached;
    NSString *_bundle;
    NSString *_name;
    CGPoint _panStart;
    CGPoint _origin;
    BOOL _origin_set;
}

+ (instancetype)shared {
    static MSOverlay *o;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ o = [MSOverlay new]; });
    return o;
}

- (void)start {
    [UIDevice.currentDevice beginGeneratingDeviceOrientationNotifications];
    [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(orientationChanged)
                                               name:UIDeviceOrientationDidChangeNotification object:nil];
    __weak typeof(self) ws = self;
    _timer = [NSTimer scheduledTimerWithTimeInterval:2.0 repeats:YES block:^(NSTimer *t) { [ws poll]; }];
    [self poll];
}

#pragma mark - 状態の確認

- (void)poll {
    __weak typeof(self) ws = self;
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
        NSString *err = nil;
        NSArray<NSString *> *st = MSRequest(@"STATUS", &err);
        NSString *bundle = nil, *name = nil;
        BOOL attached = NO;
        if (st.count) {
            NSArray *f = [st[0] componentsSeparatedByString:@"\t"];
            if (f.count >= 2 && [f[0] integerValue] > 0) {
                attached = YES;
                bundle = f[1];
            }
        }
        if (attached) {
            for (NSString *ln in MSRequest(@"APPS", &err) ?: @[]) {
                NSArray *f = [ln componentsSeparatedByString:@"\t"];
                if (f.count >= 3 && [f[1] isEqualToString:bundle]) name = f[2];
            }
        }
        dispatch_async(dispatch_get_main_queue(), ^{ [ws applyAttached:attached bundle:bundle name:name]; });
    });
}

- (void)applyAttached:(BOOL)attached bundle:(NSString *)bundle name:(NSString *)name {
    _attached = attached;
    if (!attached) {
        _buttonWindow.hidden = YES;
        [self hidePanel];
        _bundle = nil;
        return;
    }
    if (![bundle isEqualToString:_bundle]) {
        _bundle = bundle;
        _panel = nil; /* ゲームが変わったら画面を作り直す */
    }
    if (name.length) _name = name;
    [self ensureButtonWindow];
    _buttonWindow.hidden = NO;
}

#pragma mark - ウインドウ

static UIWindow *MSMakeWindow(CGRect frame) {
    UIWindowScene *scene = nil;
    for (UIScene *sc in UIApplication.sharedApplication.connectedScenes)
        if ([sc isKindOfClass:UIWindowScene.class]) { scene = (UIWindowScene *)sc; break; }
    UIWindow *w = scene ? [[UIWindow alloc] initWithWindowScene:scene] : [[UIWindow alloc] initWithFrame:frame];
    w.frame = frame;
    w.windowLevel = UIWindowLevelAlert + 1000;
    w.backgroundColor = UIColor.clearColor;
    return w;
}

- (void)ensureButtonWindow {
    if (_buttonWindow) return;
    CGRect screen = UIScreen.mainScreen.bounds;
    if (!_origin_set) {
        _origin = CGPointMake(screen.size.width - kBtn - 8, screen.size.height * 0.35);
        _origin_set = YES;
    }
    _buttonWindow = MSMakeWindow(CGRectMake(_origin.x, _origin.y, kBtn, kBtn));

    UIViewController *vc = [UIViewController new];
    vc.view.backgroundColor = UIColor.clearColor;
    UIButton *b = [UIButton buttonWithType:UIButtonTypeCustom];
    b.frame = CGRectMake(0, 0, kBtn, kBtn);
    b.backgroundColor = [UIColor colorWithRed:0.07 green:0.45 blue:0.40 alpha:0.92];
    b.layer.cornerRadius = kBtn / 2;
    b.layer.borderWidth = 1.5;
    b.layer.borderColor = UIColor.whiteColor.CGColor;
    UIImageSymbolConfiguration *ic = [UIImageSymbolConfiguration configurationWithPointSize:22 weight:UIImageSymbolWeightSemibold];
    [b setImage:[UIImage systemImageNamed:@"magnifyingglass" withConfiguration:ic] forState:UIControlStateNormal];
    b.tintColor = UIColor.whiteColor;
    [b addTarget:self action:@selector(togglePanel) forControlEvents:UIControlEventTouchUpInside];

    UIView *dot = [[UIView alloc] initWithFrame:CGRectMake(kBtn - 14, 2, 12, 12)];
    dot.backgroundColor = UIColor.systemGreenColor;
    dot.layer.cornerRadius = 6;
    dot.layer.borderWidth = 1.5;
    dot.layer.borderColor = UIColor.whiteColor.CGColor;
    dot.userInteractionEnabled = NO;
    [b addSubview:dot];

    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(dragged:)];
    [b addGestureRecognizer:pan];
    [vc.view addSubview:b];
    _btnView = b;
    _buttonWindow.rootViewController = vc;
}

- (void)dragged:(UIPanGestureRecognizer *)g {
    /* 画面全体の座標で指の位置を測る(ウインドウが動いてもずれない) */
    UIView *v = g.view;
    CGPoint p = [v convertPoint:[g locationInView:v] toCoordinateSpace:UIScreen.mainScreen.fixedCoordinateSpace];
    if (g.state == UIGestureRecognizerStateBegan) {
        _panStart = p;
        _origin = _buttonWindow.frame.origin;
        return;
    }
    CGRect screen = UIScreen.mainScreen.bounds;
    CGFloat x = _origin.x + (p.x - _panStart.x);
    CGFloat y = _origin.y + (p.y - _panStart.y);
    x = MAX(0, MIN(x, screen.size.width - kBtn));
    y = MAX(20, MIN(y, screen.size.height - kBtn - 20));
    _buttonWindow.frame = CGRectMake(x, y, kBtn, kBtn);
    if (g.state == UIGestureRecognizerStateEnded) _origin = _buttonWindow.frame.origin;
}

#pragma mark - パネル

- (CGFloat)angle {
    switch (UIDevice.currentDevice.orientation) {
        case UIDeviceOrientationLandscapeLeft: return M_PI_2;
        case UIDeviceOrientationLandscapeRight: return -M_PI_2;
        default: return 0;
    }
}

- (void)layoutPanelWindow {
    if (!_panelWindow) return;
    CGRect s = UIScreen.mainScreen.bounds;
    CGFloat angle = [self angle];
    BOOL land = (angle != 0);
    CGSize visual = land ? CGSizeMake(MIN(s.size.height - 40, 560), MIN(s.size.width - 40, 340))
                         : CGSizeMake(MIN(s.size.width - 20, 420), MIN(s.size.height * 0.62, 560));
    CGSize win = land ? CGSizeMake(visual.height, visual.width) : visual;
    CGFloat x = (s.size.width - win.width) / 2;
    CGFloat y = MAX(50, (s.size.height - win.height) / 2 - 20);
    _panelWindow.frame = CGRectMake(x, y, win.width, win.height);
    [_host layoutPanelForWindowSize:win angle:angle visual:visual];
}

- (void)orientationChanged {
    [self layoutPanelWindow];
}

- (void)togglePanel {
    if (_panelWindow && !_panelWindow.hidden) [self hidePanel];
    else [self showPanel];
}

- (void)showPanel {
    if (!_attached) return;
    if (!_panel) {
        _panel = [MSPanelViewController new];
        __weak typeof(self) ws = self;
        _panel.onClose = ^{ [ws hidePanel]; };
        _panel.onDisconnect = ^{ [ws hidePanel]; [ws poll]; };
        _host = nil;
        _panelWindow.hidden = YES;
        _panelWindow = nil;
    }
    _panel.gameName = _name ?: @"";
    if (!_panelWindow) {
        _host = [MSHostViewController new];
        _host.panel = _panel;
        _panelWindow = MSMakeWindow(CGRectMake(0, 0, 300, 400));
        _panelWindow.rootViewController = _host;
    }
    [self layoutPanelWindow];
    _panelWindow.hidden = NO;
    [_panelWindow makeKeyWindow];
    [_panel reloadAll];
}

- (void)hidePanel {
    if (!_panelWindow) return;
    [_panelWindow endEditing:YES];
    _panelWindow.hidden = YES;
}

@end

#pragma mark - 読み込み

__attribute__((constructor)) static void MSOverlayInit(void) {
    /* SpringBoard の準備ができるのを少し待ってから始める */
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(8 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [[MSOverlay shared] start];
    });
}

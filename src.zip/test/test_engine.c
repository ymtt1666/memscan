/* エンジンの単体テスト。Linux/macOS で動く。
 *   cc -O1 -I../engine test_engine.c ../engine/engine.c -lm -o test_engine && ./test_engine */
#include "engine.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#define SZ (4u << 20)

static uint8_t *mem;

static int m_regions(void *c, ms_region **out, size_t *n) {
    (void)c;
    ms_region *r = (ms_region *)malloc(2 * sizeof(ms_region));
    r[0].start = (uint64_t)(uintptr_t)mem;
    r[0].size = SZ / 2;
    r[1].start = (uint64_t)(uintptr_t)mem + SZ / 2;
    r[1].size = SZ / 2;
    *out = r;
    *n = 2;
    return 0;
}
static int inside(uint64_t a, size_t l) {
    uint64_t b = (uint64_t)(uintptr_t)mem;
    return a >= b && a + l <= b + SZ;
}
static int m_read(void *c, uint64_t a, void *buf, size_t l) {
    (void)c;
    if (!inside(a, l)) return -1;
    memcpy(buf, (void *)(uintptr_t)a, l);
    return 0;
}
static int m_write(void *c, uint64_t a, const void *buf, size_t l) {
    (void)c;
    if (!inside(a, l)) return -1;
    memcpy((void *)(uintptr_t)a, buf, l);
    return 0;
}

#define CHECK(x) do { if (!(x)) { printf("FAIL line %d: %s\n", __LINE__, #x); exit(1); } } while (0)

static void put32(size_t off, int32_t v) { memcpy(mem + off, &v, 4); }
static void putf(size_t off, float v) { memcpy(mem + off, &v, 4); }

int main(void) {
    mem = (uint8_t *)aligned_alloc(4096, SZ);
    memset(mem, 0, SZ);
    ms_backend be = { NULL, m_regions, m_read, m_write, NULL };
    ms_engine e;
    ms_init(&e, be);
    char err[256];

    /* 変換 */
    uint64_t raw;
    CHECK(ms_parse(MS_I32, "1500", &raw) == 0 && (int32_t)raw == 1500);
    CHECK(ms_parse(MS_I32, "-5", &raw) == 0 && (int32_t)raw == -5);
    CHECK(ms_parse(MS_I32, "4294967296", &raw) != 0);
    CHECK(ms_parse(MS_I32, "abc", &raw) != 0);
    CHECK(ms_parse(MS_I32, "", &raw) != 0);
    CHECK(ms_parse(MS_I8, "300", &raw) != 0);
    CHECK(ms_parse(MS_F32, "1.5", &raw) == 0);
    char s[64];
    ms_format(MS_F32, raw, s, sizeof s);
    CHECK(strcmp(s, "1.5") == 0);
    ms_type tt;
    CHECK(ms_type_parse("f64", &tt) == 0 && tt == MS_F64);
    CHECK(ms_type_parse("zzz", &tt) != 0);

    /* 整数: 1500 が 3 か所、ほかは別の値 */
    size_t A = 0x1000, B = 0x50000, C = 0x250000;
    put32(A, 1500); put32(B, 1500); put32(C, 1500);
    put32(0x2000, 1501);
    CHECK(ms_first(&e, MS_I32, "1500", err, sizeof err) == 0);
    CHECK(e.n == 3);

    /* コインが 1500 -> 1200 に減った。A と C だけ追従 */
    put32(A, 1200); put32(C, 1200);
    CHECK(ms_next(&e, MS_EQ, "1200", err, sizeof err) == 0);
    CHECK(e.n == 2);

    uint64_t addr, cur, old;
    CHECK(ms_get_result(&e, 0, &addr, &cur, &old) == 0);
    CHECK(addr == (uint64_t)(uintptr_t)mem + A && (int32_t)cur == 1200 && (int32_t)old == 1200);
    CHECK(ms_get_result(&e, 9, &addr, &cur, &old) == -1);

    /* 減った/増えた/変わらない */
    put32(A, 1100);
    CHECK(ms_next(&e, MS_DEC, NULL, err, sizeof err) == 0);
    CHECK(e.n == 1);
    CHECK(ms_next(&e, MS_SAME, NULL, err, sizeof err) == 0);
    CHECK(e.n == 1);
    put32(A, 2000);
    CHECK(ms_next(&e, MS_DEC, NULL, err, sizeof err) == 0);
    CHECK(e.n == 0);

    /* 検索前の next はエラー、値なしの EQ もエラー */
    ms_reset(&e);
    CHECK(ms_next(&e, MS_INC, NULL, err, sizeof err) == -1);
    put32(A, 77);
    CHECK(ms_first(&e, MS_I32, "77", err, sizeof err) == 0 && e.n == 1);
    CHECK(ms_next(&e, MS_EQ, NULL, err, sizeof err) == -1);
    CHECK(ms_first(&e, MS_I32, "x1", err, sizeof err) == -1);

    /* 書き換えと元に戻す */
    uint64_t target = (uint64_t)(uintptr_t)mem + A;
    ms_parse(MS_I32, "9999999", &raw);
    CHECK(ms_write_value(&e, target, MS_I32, raw, 1) == 0);
    int32_t chk; memcpy(&chk, mem + A, 4);
    CHECK(chk == 9999999);
    CHECK(ms_undo(&e) == 0);
    memcpy(&chk, mem + A, 4);
    CHECK(chk == 77);
    CHECK(ms_undo(&e) == -1);
    CHECK(ms_write_value(&e, 1234, MS_I32, 1, 1) == -1);

    /* 小数 */
    memset(mem, 0, SZ);
    putf(0x3000, 12.5f); putf(0x3100, 12.5f); putf(0x3200, 12.75f);
    CHECK(ms_first(&e, MS_F32, "12.5", err, sizeof err) == 0 && e.n == 2);
    putf(0x3000, 20.0f);
    CHECK(ms_next(&e, MS_INC, NULL, err, sizeof err) == 0 && e.n == 1);

    /* 不明な初期値: 範囲が大きすぎて拒否される (4MB/4 = 1M < 6M なので通る) */
    memset(mem, 0, SZ);
    put32(0x100, 10); put32(0x200, 10);
    CHECK(ms_first(&e, MS_I32, NULL, err, sizeof err) == 0);
    CHECK(e.n == SZ / 4);
    put32(0x100, 11);
    CHECK(ms_next(&e, MS_INC, NULL, err, sizeof err) == 0 && e.n == 1);

    /* 64bit */
    memset(mem, 0, SZ);
    int64_t big = 5000000000LL;
    memcpy(mem + 0x800, &big, 8);
    CHECK(ms_first(&e, MS_I64, "5000000000", err, sizeof err) == 0 && e.n == 1);

    ms_free(&e);
    free(mem);
    printf("engine: all tests passed\n");
    return 0;
}

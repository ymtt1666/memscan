/* 結合テスト用の「ゲーム役」。標準入力の命令で値を変え、値を表示する。 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

volatile int g_coin = 1500;            /* 本体の中(静的) */
volatile int *g_heap;                  /* ヒープ上 */
volatile float g_hp = 80.5f;

int main(void) {
    g_heap = (int *)malloc(4096);
    *g_heap = 1500;
    setvbuf(stdout, NULL, _IOLBF, 0);
    printf("ready %d\n", getpid());
    char line[128];
    while (fgets(line, sizeof line, stdin)) {
        int v;
        float f;
        if (sscanf(line, "coin %d", &v) == 1) { g_coin = v; *g_heap = v; }
        else if (sscanf(line, "hp %f", &f) == 1) g_hp = f;
        else if (!strncmp(line, "show", 4)) printf("coin=%d heap=%d hp=%.2f\n", g_coin, *g_heap, (double)g_hp);
        else if (!strncmp(line, "quit", 4)) break;
    }
    return 0;
}

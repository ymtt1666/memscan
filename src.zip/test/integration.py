#!/usr/bin/env python3
"""デーモンを実際に起動して、命令のやり取りを通しで確認する (Linux 用)。"""
import os, socket, subprocess, sys, time

SOCK = "/tmp/ms_test.sock"
DATA = "/tmp/ms_test_data"
HERE = os.path.dirname(os.path.abspath(__file__))
DAEMON = sys.argv[1]
TARGET = sys.argv[2]

def req(cmd):
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.connect(SOCK)
    s.sendall((cmd + "\n").encode())
    buf = b""
    while not buf.endswith(b"\n.\n"):
        d = s.recv(65536)
        if not d:
            break
        buf += d
    s.close()
    lines = buf.decode().split("\n")[:-2]
    return lines[0], lines[1:]

def ok(cmd):
    h, body = req(cmd)
    assert h == "OK", f"{cmd!r} -> {h}"
    return body

def bad(cmd):
    h, _ = req(cmd)
    assert h.startswith("ERR"), f"{cmd!r} should fail, got {h}"
    return h

for p in (SOCK,):
    if os.path.exists(p): os.unlink(p)
subprocess.run(["rm", "-rf", DATA])

game = subprocess.Popen([TARGET], stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True, bufsize=1)
pid = int(game.stdout.readline().split()[1])
def say(c):
    game.stdin.write(c + "\n"); game.stdin.flush()
def show():
    say("show"); return game.stdout.readline().strip()

env = dict(os.environ, MS_FAKE_APPS=f"{pid}:com.test.game:テストゲーム")
d = subprocess.Popen([DAEMON], env=env)
for _ in range(50):
    if os.path.exists(SOCK): break
    time.sleep(0.1)

try:
    ok("PING")
    apps = ok("APPS")
    assert apps == [f"{pid}\tcom.test.game\tテストゲーム"], apps

    bad("FIRST i32 1500")               # 接続前はエラー
    ok(f"ATTACH {pid} com.test.game")
    st = ok("STATUS")[0].split("\t")
    assert st[0] == str(pid) and st[1] == "com.test.game", st

    n = int(ok("FIRST i32 1500")[0])
    assert n >= 2, n                    # 静的とヒープの 2 か所以上
    say("coin 1200")
    n = int(ok("NEXT eq 1200")[0])
    assert 2 <= n < 20, n
    rows = [r.split("\t") for r in ok("RESULTS 0 50")]
    assert all(r[1] == "1200" for r in rows), rows

    say("coin 1100")
    n2 = int(ok("NEXT dec")[0])
    assert n2 == n, (n, n2)

    # 書き換え: 全候補を 9999999 にしてゲーム側の値を確認
    for r in rows:
        ok(f"SET {r[0]} i32 9999999")
    assert show().startswith("coin=9999999 heap=9999999"), show()
    ok("UNDO")                          # 最後の 1 件だけ戻る
    ok("UNFREEZE ffff")

    # 固定: ゲーム側で値を変えても戻される
    for r in rows:
        ok(f"FREEZE {r[0]} i32 5000")
    say("coin 1"); time.sleep(0.3)
    assert show().startswith("coin=5000 heap=5000"), show()
    fz = ok("STATUS")[0].split("\t")
    assert int(fz[4]) == len(rows), fz
    ok("STOPALL")
    say("coin 1"); time.sleep(0.3)
    assert show().startswith("coin=1 heap=1"), show()

    # 保存(静的アドレスは M+ になる) と 呼び出し
    ok("RESET")
    ok("FIRST i32 1")
    say("coin 31337")
    ok("NEXT eq 31337")
    cand = [r.split("\t")[0] for r in ok("RESULTS 0 50")]
    kind = None
    for a in cand:
        kind = ok(f"SAVE {a} i32 777 1 コイン を 固定")[0]
    cheats = [c.split("\t") for c in ok("CHEATS")]
    assert len(cheats) == len(cand) and cheats[0][1] == "コイン を 固定", cheats
    # 同じゲームを再接続しても、静的(M+)なものは使い回せる
    ok("DETACH"); ok(f"ATTACH {pid} com.test.game")
    applied = 0
    for c in ok("CHEATS"):
        idx = c.split("\t")[0]
        h, _ = req(f"APPLY {idx}")
        applied += h == "OK"
    assert applied >= 1, "static cheat did not apply"
    time.sleep(0.2); say("coin 5")
    time.sleep(0.3)
    assert "coin=777" in show(), show()
    ok("STOPALL")
    for c in ok("CHEATS"):
        ok(f"DELCHEAT {c.split(chr(9))[0]}")
        break

    # 小数
    ok("RESET")
    ok("FIRST f32 80.5")
    say("hp 55.25")
    assert int(ok("NEXT eq 55.25")[0]) >= 1
    h = [r.split("\t") for r in ok("RESULTS 0 5")]
    ok(f"SET {h[0][0]} f32 100")
    assert "hp=100.00" in show(), show()

    # 不正な入力
    bad("FIRST i32 abc"); bad("FIRST zz 1"); bad("NEXT eq x"); bad("HOGE")
    bad("ATTACH 999999 a.b")

    # ゲーム終了で自動的に切断される
    say("quit"); game.wait(timeout=5)
    time.sleep(0.2)
    assert ok("STATUS")[0].split("\t")[0] == "0"
    print("integration: all passed")
finally:
    d.terminate()
    if game.poll() is None: game.kill()

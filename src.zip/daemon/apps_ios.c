/* iOS 用: 動いているプロセスのうち、App としてインストールされたものを一覧にする */
#ifdef __APPLE__

#include "backend.h"
#include "ms_config.h"
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <CoreFoundation/CoreFoundation.h>

extern int proc_listallpids(void *buffer, int buffersize);
extern int proc_pidpath(int pid, void *buffer, uint32_t buffersize);

static int cfstr(CFDictionaryRef d, const char *key, char *out, size_t n) {
    CFStringRef k = CFStringCreateWithCString(NULL, key, kCFStringEncodingUTF8);
    CFTypeRef v = CFDictionaryGetValue(d, k);
    CFRelease(k);
    if (!v || CFGetTypeID(v) != CFStringGetTypeID()) return 0;
    return CFStringGetCString((CFStringRef)v, out, (CFIndex)n, kCFStringEncodingUTF8);
}

static CFDictionaryRef read_info(const char *app_dir) {
    char p[2048];
    snprintf(p, sizeof p, "%s/Info.plist", app_dir);
    FILE *f = fopen(p, "rb");
    if (!f) return NULL;
    fseek(f, 0, SEEK_END);
    long sz = ftell(f);
    fseek(f, 0, SEEK_SET);
    if (sz <= 0 || sz > (8 << 20)) { fclose(f); return NULL; }
    uint8_t *buf = (uint8_t *)malloc((size_t)sz);
    if (!buf || fread(buf, 1, (size_t)sz, f) != (size_t)sz) { free(buf); fclose(f); return NULL; }
    fclose(f);
    CFDataRef data = CFDataCreate(NULL, buf, sz);
    free(buf);
    CFPropertyListRef pl = CFPropertyListCreateWithData(NULL, data, kCFPropertyListImmutable, NULL, NULL);
    CFRelease(data);
    if (pl && CFGetTypeID(pl) == CFDictionaryGetTypeID()) return (CFDictionaryRef)pl;
    if (pl) CFRelease(pl);
    return NULL;
}

int ms_apps_list(FILE *out) {
    int cap = proc_listallpids(NULL, 0);
    if (cap <= 0) return -1;
    int *pids = (int *)malloc((size_t)(cap + 64) * sizeof(int));
    if (!pids) return -1;
    int n = proc_listallpids(pids, (cap + 64) * (int)sizeof(int)); /* 戻り値は PID の個数 */
    if (n <= 0) { free(pids); return -1; }
    int self = getpid();

    for (int i = 0; i < n; i++) {
        int pid = pids[i];
        if (pid <= 1 || pid == self) continue;
        char path[2048];
        if (proc_pidpath(pid, path, sizeof path) <= 0) continue;
        if (!strstr(path, "/Bundle/Application/")) continue;
        char *app = strstr(path, ".app/");
        if (!app) continue;
        app[4] = 0; /* ".app" で切る */

        CFDictionaryRef info = read_info(path);
        if (!info) continue;
        char bid[256] = "", name[256] = "";
        cfstr(info, "CFBundleIdentifier", bid, sizeof bid);
        if (!cfstr(info, "CFBundleDisplayName", name, sizeof name))
            cfstr(info, "CFBundleName", name, sizeof name);
        CFRelease(info);
        if (!bid[0] || strcmp(bid, MS_SELF_BUNDLE) == 0) continue;
        if (!name[0]) snprintf(name, sizeof name, "%s", bid);
        for (char *c = name; *c; c++) if (*c == '\t' || *c == '\n') *c = ' ';
        fprintf(out, "%d\t%s\t%s\n", pid, bid, name);
    }
    free(pids);
    return 0;
}

#endif /* __APPLE__ */

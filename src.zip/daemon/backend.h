#ifndef MS_BACKEND_H
#define MS_BACKEND_H

#include <stdio.h>
#include "engine.h"

/* pid のプロセスに接続する。成功で 0。ctx は ms_backend_close で解放する。 */
int  ms_backend_open(ms_backend *be, int pid, char *err, size_t errn);
void ms_backend_close(ms_backend *be);

/* 起動中アプリの一覧を "pid\tbundle\tname\n" の形で out に書く */
int  ms_apps_list(FILE *out);

#endif

/* memscand: ゲームのメモリを探して書き換える裏方プログラム (root で常駐)。
 * 画面側(アプリ・丸ボタン)は UNIX ソケットで命令を送る。 */
#define _GNU_SOURCE
#include "backend.h"
#include "ms_config.h"

#include <errno.h>
#include <pthread.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/un.h>
#include <unistd.h>

#define MAX_FREEZE 256

typedef struct { uint64_t addr; ms_type type; uint64_t raw; } freeze_ent;

static pthread_mutex_t g_lock = PTHREAD_MUTEX_INITIALIZER;
static ms_engine g_eng;
static int g_attached = 0;
static int g_pid = 0;
static char g_bundle[256] = "";
static freeze_ent g_fz[MAX_FREEZE];
static size_t g_nfz = 0;

/* ---------- 応答 ---------- */

static void r_ok(FILE *o) { fputs("OK\n", o); }
static void r_end(FILE *o) { fputs(".\n", o); fflush(o); }
static void r_err(FILE *o, const char *msg) { fprintf(o, "ERR %s\n.\n", msg); fflush(o); }

/* ---------- 接続の管理 (g_lock を持って呼ぶ) ---------- */

static void detach_locked(void) {
    if (!g_attached) return;
    ms_free(&g_eng);
    ms_backend_close(&g_eng.be);
    memset(&g_eng, 0, sizeof g_eng);
    g_attached = 0;
    g_pid = 0;
    g_bundle[0] = 0;
    g_nfz = 0;
}

static int alive(int pid) { return kill(pid, 0) == 0 || errno == EPERM; }

static void check_alive_locked(void) {
    if (g_attached && !alive(g_pid)) detach_locked();
}

/* ---------- 固定(フリーズ) ---------- */

static void *freeze_thread(void *arg) {
    (void)arg;
    for (;;) {
        usleep(50 * 1000);
        pthread_mutex_lock(&g_lock);
        check_alive_locked();
        if (g_attached)
            for (size_t i = 0; i < g_nfz; i++)
                ms_write_value(&g_eng, g_fz[i].addr, g_fz[i].type, g_fz[i].raw, 0);
        pthread_mutex_unlock(&g_lock);
    }
    return NULL;
}

static void freeze_add(uint64_t addr, ms_type t, uint64_t raw) {
    for (size_t i = 0; i < g_nfz; i++)
        if (g_fz[i].addr == addr) { g_fz[i].type = t; g_fz[i].raw = raw; return; }
    if (g_nfz < MAX_FREEZE) {
        g_fz[g_nfz].addr = addr;
        g_fz[g_nfz].type = t;
        g_fz[g_nfz].raw = raw;
        g_nfz++;
    }
}

static int freeze_del(uint64_t addr) {
    for (size_t i = 0; i < g_nfz; i++)
        if (g_fz[i].addr == addr) {
            g_fz[i] = g_fz[g_nfz - 1];
            g_nfz--;
            return 1;
        }
    return 0;
}

static int is_frozen(uint64_t addr) {
    for (size_t i = 0; i < g_nfz; i++) if (g_fz[i].addr == addr) return 1;
    return 0;
}

/* ---------- 保存したチート ---------- */

static void mkdirs(const char *path) {
    char tmp[512];
    snprintf(tmp, sizeof tmp, "%s", path);
    for (char *p = tmp + 1; *p; p++)
        if (*p == '/') { *p = 0; mkdir(tmp, 0755); *p = '/'; }
    mkdir(tmp, 0755);
}

static void cheat_path(char *out, size_t n) { snprintf(out, n, "%s/cheats.tsv", MS_DATA_DIR); }

static void sanitize(char *s) {
    for (; *s; s++) if (*s == '\t' || *s == '\n' || *s == '\r') *s = ' ';
}

/* アドレスを「本体の先頭からの位置(M+)」か「そのままの値(A+)」にする */
static void addr_to_spec(uint64_t addr, char *out, size_t n) {
    uint64_t base, size;
    if (g_eng.be.main_image && g_eng.be.main_image(g_eng.be.ctx, &base, &size) == 0 &&
        addr >= base && addr < base + size)
        snprintf(out, n, "M+%llx", (unsigned long long)(addr - base));
    else
        snprintf(out, n, "A+%llx", (unsigned long long)addr);
}

static int spec_to_addr(const char *spec, uint64_t *addr) {
    if (strlen(spec) < 3 || spec[1] != '+') return -1;
    unsigned long long v = strtoull(spec + 2, NULL, 16);
    if (spec[0] == 'A') { *addr = v; return 0; }
    if (spec[0] == 'M') {
        uint64_t base, size;
        if (!g_eng.be.main_image || g_eng.be.main_image(g_eng.be.ctx, &base, &size) != 0) return -1;
        *addr = base + v;
        return 0;
    }
    return -1;
}

typedef struct { char bundle[256], name[128], spec[40], type[8], value[64]; int freeze; } cheat_t;

static int parse_cheat_line(char *line, cheat_t *c) {
    line[strcspn(line, "\r\n")] = 0;
    char *f[6];
    int k = 0;
    char *p = line;
    while (k < 6) {
        f[k++] = p;
        char *t = strchr(p, '\t');
        if (!t) break;
        *t = 0;
        p = t + 1;
    }
    if (k != 6) return -1;
    snprintf(c->bundle, sizeof c->bundle, "%s", f[0]);
    snprintf(c->name, sizeof c->name, "%s", f[1]);
    snprintf(c->spec, sizeof c->spec, "%s", f[2]);
    snprintf(c->type, sizeof c->type, "%s", f[3]);
    snprintf(c->value, sizeof c->value, "%s", f[4]);
    c->freeze = atoi(f[5]);
    return 0;
}

/* idx 行目(1 始まり)を取り出す。見つかれば 0 */
static int cheat_get(int idx, cheat_t *out) {
    char path[512], line[1024];
    cheat_path(path, sizeof path);
    FILE *f = fopen(path, "r");
    if (!f) return -1;
    int ln = 0, rc = -1;
    while (fgets(line, sizeof line, f)) {
        ln++;
        if (ln == idx) { rc = parse_cheat_line(line, out); break; }
    }
    fclose(f);
    return rc;
}

static int cheat_delete(int idx) {
    char path[512], tmp[560], line[1024];
    cheat_path(path, sizeof path);
    snprintf(tmp, sizeof tmp, "%s.tmp", path);
    FILE *f = fopen(path, "r");
    if (!f) return -1;
    FILE *o = fopen(tmp, "w");
    if (!o) { fclose(f); return -1; }
    int ln = 0;
    while (fgets(line, sizeof line, f)) {
        ln++;
        if (ln != idx) fputs(line, o);
    }
    fclose(f);
    fclose(o);
    return rename(tmp, path);
}

/* ---------- 命令の処理 ---------- */

#define MAXTOK 8

static int tokenize(char *line, char **tok, int max) {
    int n = 0;
    char *save = NULL;
    for (char *t = strtok_r(line, " \t", &save); t && n < max; t = strtok_r(NULL, " \t", &save))
        tok[n++] = t;
    return n;
}

static int need_attached(FILE *o) {
    if (!g_attached) { r_err(o, "ゲームに接続していません"); return 0; }
    return 1;
}

static void cmd_apps(FILE *o) {
    r_ok(o);
    ms_apps_list(o);
    r_end(o);
}

static void cmd_attach(FILE *o, char **tok, int n) {
    if (n < 3) { r_err(o, "使い方: ATTACH pid bundle"); return; }
    int pid = atoi(tok[1]);
    if (pid <= 1 || !alive(pid)) { r_err(o, "そのゲームは起動していません"); return; }
    detach_locked();
    ms_backend be;
    memset(&be, 0, sizeof be);
    char err[256] = "";
    if (ms_backend_open(&be, pid, err, sizeof err) != 0) { r_err(o, err); return; }
    ms_init(&g_eng, be);
    g_attached = 1;
    g_pid = pid;
    snprintf(g_bundle, sizeof g_bundle, "%s", tok[2]);
    g_nfz = 0;
    r_ok(o);
    r_end(o);
}

static void cmd_status(FILE *o) {
    check_alive_locked();
    r_ok(o);
    fprintf(o, "%d\t%s\t%s\t%zu\t%zu\t%zu\n", g_attached ? g_pid : 0, g_bundle,
            g_attached ? ms_type_name(g_eng.type) : "-", g_attached && g_eng.active ? g_eng.n : (size_t)0,
            g_nfz, g_attached ? g_eng.nundo : (size_t)0);
    r_end(o);
}

static void cmd_first(FILE *o, char **tok, int n) {
    if (!need_attached(o)) return;
    if (n < 3) { r_err(o, "使い方: FIRST 型 値"); return; }
    ms_type t;
    if (ms_type_parse(tok[1], &t) != 0) { r_err(o, "型が正しくありません"); return; }
    char err[256] = "";
    const char *v = strcmp(tok[2], "?") == 0 ? NULL : tok[2];
    if (ms_first(&g_eng, t, v, err, sizeof err) != 0) { r_err(o, err); return; }
    r_ok(o);
    fprintf(o, "%zu\n", g_eng.n);
    r_end(o);
}

static void cmd_next(FILE *o, char **tok, int n) {
    if (!need_attached(o)) return;
    if (n < 2) { r_err(o, "使い方: NEXT モード [値]"); return; }
    ms_mode m;
    if (!strcmp(tok[1], "eq")) m = MS_EQ;
    else if (!strcmp(tok[1], "inc")) m = MS_INC;
    else if (!strcmp(tok[1], "dec")) m = MS_DEC;
    else if (!strcmp(tok[1], "chg")) m = MS_CHG;
    else if (!strcmp(tok[1], "same")) m = MS_SAME;
    else { r_err(o, "モードが正しくありません"); return; }
    char err[256] = "";
    if (ms_next(&g_eng, m, n > 2 ? tok[2] : NULL, err, sizeof err) != 0) { r_err(o, err); return; }
    r_ok(o);
    fprintf(o, "%zu\n", g_eng.n);
    r_end(o);
}

static void cmd_results(FILE *o, char **tok, int n) {
    if (!need_attached(o)) return;
    size_t off = n > 1 ? (size_t)strtoull(tok[1], NULL, 10) : 0;
    size_t lim = n > 2 ? (size_t)strtoull(tok[2], NULL, 10) : 20;
    if (lim > 200) lim = 200;
    r_ok(o);
    if (g_eng.active) {
        for (size_t i = off; i < off + lim && i < g_eng.n; i++) {
            uint64_t a, cur, old;
            int rc = ms_get_result(&g_eng, i, &a, &cur, &old);
            if (rc < 0) break;
            char cs[64] = "?", os[64];
            if (rc == 0) ms_format(g_eng.type, cur, cs, sizeof cs);
            ms_format(g_eng.type, old, os, sizeof os);
            fprintf(o, "%llx\t%s\t%s\t%d\n", (unsigned long long)a, cs, os, is_frozen(a));
        }
    }
    r_end(o);
}

static void cmd_set(FILE *o, char **tok, int n, int freeze) {
    if (!need_attached(o)) return;
    if (n < 4) { r_err(o, "使い方: SET アドレス 型 値"); return; }
    uint64_t addr = strtoull(tok[1], NULL, 16), raw;
    ms_type t;
    if (ms_type_parse(tok[2], &t) != 0 || ms_parse(t, tok[3], &raw) != 0) {
        r_err(o, "数値を正しく入力してください");
        return;
    }
    if (ms_write_value(&g_eng, addr, t, raw, 1) != 0) {
        r_err(o, "書き換えられませんでした");
        return;
    }
    if (freeze) freeze_add(addr, t, raw);
    r_ok(o);
    r_end(o);
}

static void cmd_unfreeze(FILE *o, char **tok, int n) {
    if (n < 2) { r_err(o, "使い方: UNFREEZE アドレス"); return; }
    freeze_del(strtoull(tok[1], NULL, 16));
    r_ok(o);
    r_end(o);
}

static void cmd_save(FILE *o, char *rest_line, char **tok, int n) {
    if (!need_attached(o)) return;
    /* SAVE アドレス 型 値 固定(0/1) 名前... */
    if (n < 6) { r_err(o, "使い方: SAVE アドレス 型 値 固定 名前"); return; }
    uint64_t addr = strtoull(tok[1], NULL, 16), raw;
    ms_type t;
    if (ms_type_parse(tok[2], &t) != 0 || ms_parse(t, tok[3], &raw) != 0) {
        r_err(o, "数値を正しく入力してください");
        return;
    }
    char name[128];
    /* 名前は残りの文字列すべて(空白を含められる) */
    const char *p = rest_line;
    for (int i = 0; i < 5 && p; i++) {
        p += strspn(p, " \t");
        p += strcspn(p, " \t");
    }
    p += strspn(p, " \t");
    snprintf(name, sizeof name, "%s", p);
    sanitize(name);
    if (!name[0]) { r_err(o, "名前を入力してください"); return; }

    char spec[40];
    addr_to_spec(addr, spec, sizeof spec);
    mkdirs(MS_DATA_DIR);
    char path[512];
    cheat_path(path, sizeof path);
    FILE *f = fopen(path, "a");
    if (!f) { r_err(o, "保存できませんでした"); return; }
    fprintf(f, "%s\t%s\t%s\t%s\t%s\t%d\n", g_bundle, name, spec, tok[2], tok[3], atoi(tok[4]) ? 1 : 0);
    fclose(f);
    r_ok(o);
    fprintf(o, "%s\n", spec[0] == 'M' ? "static" : "dynamic");
    r_end(o);
}

static void cmd_cheats(FILE *o) {
    if (!need_attached(o)) return;
    char path[512], line[1024];
    cheat_path(path, sizeof path);
    r_ok(o);
    FILE *f = fopen(path, "r");
    if (f) {
        int ln = 0;
        while (fgets(line, sizeof line, f)) {
            ln++;
            cheat_t c;
            if (parse_cheat_line(line, &c) != 0 || strcmp(c.bundle, g_bundle) != 0) continue;
            uint64_t a = 0;
            int ok = (spec_to_addr(c.spec, &a) == 0);
            fprintf(o, "%d\t%s\t%s\t%s\t%d\t%llx\t%d\n", ln, c.name, c.type, c.value, c.freeze,
                    (unsigned long long)(ok ? a : 0), ok ? is_frozen(a) : 0);
        }
        fclose(f);
    }
    r_end(o);
}

static void cmd_apply(FILE *o, char **tok, int n) {
    if (!need_attached(o)) return;
    if (n < 2) { r_err(o, "使い方: APPLY 番号"); return; }
    cheat_t c;
    if (cheat_get(atoi(tok[1]), &c) != 0 || strcmp(c.bundle, g_bundle) != 0) {
        r_err(o, "チートが見つかりません");
        return;
    }
    uint64_t addr, raw, cur;
    ms_type t;
    if (spec_to_addr(c.spec, &addr) != 0 || ms_type_parse(c.type, &t) != 0 || ms_parse(t, c.value, &raw) != 0 ||
        ms_read_value(&g_eng, addr, t, &cur) != 0) {
        r_err(o, "この場所は今は使えません。もう一度探してください");
        return;
    }
    if (ms_write_value(&g_eng, addr, t, raw, 1) != 0) { r_err(o, "書き換えられませんでした"); return; }
    if (c.freeze) freeze_add(addr, t, raw);
    r_ok(o);
    r_end(o);
}

static void cmd_delcheat(FILE *o, char **tok, int n) {
    if (n < 2) { r_err(o, "使い方: DELCHEAT 番号"); return; }
    if (cheat_delete(atoi(tok[1])) != 0) { r_err(o, "削除できませんでした"); return; }
    r_ok(o);
    r_end(o);
}

static void handle_line(FILE *o, char *line) {
    line[strcspn(line, "\r\n")] = 0;
    char copy[2048];
    snprintf(copy, sizeof copy, "%s", line);
    char *tok[MAXTOK];
    int n = tokenize(copy, tok, MAXTOK);
    if (n == 0) { r_err(o, "空の命令です"); return; }
    const char *c = tok[0];

    pthread_mutex_lock(&g_lock);
    if (!strcmp(c, "PING")) { r_ok(o); r_end(o); }
    else if (!strcmp(c, "APPS")) cmd_apps(o);
    else if (!strcmp(c, "ATTACH")) cmd_attach(o, tok, n);
    else if (!strcmp(c, "DETACH")) { detach_locked(); r_ok(o); r_end(o); }
    else if (!strcmp(c, "STATUS")) cmd_status(o);
    else if (!strcmp(c, "FIRST")) cmd_first(o, tok, n);
    else if (!strcmp(c, "NEXT")) cmd_next(o, tok, n);
    else if (!strcmp(c, "RESULTS")) cmd_results(o, tok, n);
    else if (!strcmp(c, "RESET")) { if (g_attached) ms_reset(&g_eng); r_ok(o); r_end(o); }
    else if (!strcmp(c, "SET")) cmd_set(o, tok, n, 0);
    else if (!strcmp(c, "FREEZE")) cmd_set(o, tok, n, 1);
    else if (!strcmp(c, "UNFREEZE")) cmd_unfreeze(o, tok, n);
    else if (!strcmp(c, "STOPALL")) { g_nfz = 0; r_ok(o); r_end(o); }
    else if (!strcmp(c, "UNDO")) {
        if (!need_attached(o)) { /* 応答済み */ }
        else if (ms_undo(&g_eng) != 0) r_err(o, "元に戻せる変更がありません");
        else { r_ok(o); r_end(o); }
    }
    else if (!strcmp(c, "SAVE")) cmd_save(o, line, tok, n);
    else if (!strcmp(c, "CHEATS")) cmd_cheats(o);
    else if (!strcmp(c, "APPLY")) cmd_apply(o, tok, n);
    else if (!strcmp(c, "DELCHEAT")) cmd_delcheat(o, tok, n);
    else r_err(o, "知らない命令です");
    pthread_mutex_unlock(&g_lock);
}

/* ---------- ソケット ---------- */

static void *client_thread(void *arg) {
    int fd = (int)(intptr_t)arg;
    FILE *in = fdopen(fd, "r");
    FILE *out = fdopen(dup(fd), "w");
    if (in && out) {
        char line[2048];
        while (fgets(line, sizeof line, in)) handle_line(out, line);
    }
    if (in) fclose(in);
    if (out) fclose(out);
    return NULL;
}

int main(void) {
    signal(SIGPIPE, SIG_IGN);
    mkdirs(MS_DATA_DIR);

    char dir[256];
    snprintf(dir, sizeof dir, "%s", MS_SOCK_PATH);
    char *slash = strrchr(dir, '/');
    if (slash) { *slash = 0; mkdirs(dir); }

    int ls = socket(AF_UNIX, SOCK_STREAM, 0);
    if (ls < 0) { perror("socket"); return 1; }
    struct sockaddr_un sa;
    memset(&sa, 0, sizeof sa);
    sa.sun_family = AF_UNIX;
    snprintf(sa.sun_path, sizeof sa.sun_path, "%s", MS_SOCK_PATH);
    unlink(MS_SOCK_PATH);
    umask(0);
    if (bind(ls, (struct sockaddr *)&sa, sizeof sa) != 0) { perror("bind"); return 1; }
    chmod(MS_SOCK_PATH, 0666);
    if (listen(ls, 8) != 0) { perror("listen"); return 1; }

    pthread_t ft;
    pthread_create(&ft, NULL, freeze_thread, NULL);
    pthread_detach(ft);

    for (;;) {
        int fd = accept(ls, NULL, NULL);
        if (fd < 0) {
            if (errno == EINTR) continue;
            perror("accept");
            sleep(1);
            continue;
        }
        /* root(0) と mobile(501) 以外からの接続は受け付けない */
        uid_t uid = (uid_t)-1;
#ifdef __linux__
        struct ucred cr;
        socklen_t crl = sizeof cr;
        if (getsockopt(fd, SOL_SOCKET, SO_PEERCRED, &cr, &crl) == 0) uid = cr.uid;
#else
        gid_t gid;
        if (getpeereid(fd, &uid, &gid) != 0) uid = (uid_t)-1;
#endif
        if (uid != 0 && uid != 501) {
            close(fd);
            continue;
        }
        pthread_t t;
        if (pthread_create(&t, NULL, client_thread, (void *)(intptr_t)fd) == 0) pthread_detach(t);
        else close(fd);
    }
    return 0;
}

/* 動作確認用: Linux では環境変数 MS_FAKE_APPS ("pid:bundle:name,...") をそのまま返す */
#ifdef __linux__

#include "backend.h"
#include <stdlib.h>
#include <string.h>

int ms_apps_list(FILE *out) {
    const char *s = getenv("MS_FAKE_APPS");
    if (!s) return 0;
    char *copy = strdup(s), *save = NULL;
    for (char *t = strtok_r(copy, ",", &save); t; t = strtok_r(NULL, ",", &save)) {
        char *a = strchr(t, ':');
        if (!a) continue;
        *a++ = 0;
        char *b = strchr(a, ':');
        if (!b) continue;
        *b++ = 0;
        fprintf(out, "%s\t%s\t%s\n", t, a, b);
    }
    free(copy);
    return 0;
}

#endif

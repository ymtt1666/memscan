/* 動作確認用: Linux の /proc/<pid>/mem を使う。iOS のビルドには入らない。 */
#ifdef __linux__

#define _GNU_SOURCE
#include "backend.h"
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>

typedef struct { int fd; int pid; } lctx;

static int l_regions(void *c, ms_region **out, size_t *n) {
    lctx *l = (lctx *)c;
    char path[64];
    snprintf(path, sizeof path, "/proc/%d/maps", l->pid);
    FILE *f = fopen(path, "r");
    if (!f) return -1;
    size_t cap = 64, cnt = 0;
    ms_region *r = (ms_region *)malloc(cap * sizeof(ms_region));
    char line[512];
    while (fgets(line, sizeof line, f)) {
        unsigned long long s, e;
        char perms[8];
        if (sscanf(line, "%llx-%llx %7s", &s, &e, perms) != 3) continue;
        if (perms[0] != 'r' || perms[1] != 'w' || perms[3] != 'p') continue;
        if (strstr(line, "[vvar") || strstr(line, "[vsyscall")) continue;
        if (cnt == cap) { cap *= 2; r = (ms_region *)realloc(r, cap * sizeof(ms_region)); }
        r[cnt].start = s;
        r[cnt].size = e - s;
        cnt++;
    }
    fclose(f);
    *out = r;
    *n = cnt;
    return 0;
}

static int l_read(void *c, uint64_t addr, void *buf, size_t len) {
    lctx *l = (lctx *)c;
    ssize_t g = pread(l->fd, buf, len, (off_t)addr);
    return g == (ssize_t)len ? 0 : -1;
}

static int l_write(void *c, uint64_t addr, const void *buf, size_t len) {
    lctx *l = (lctx *)c;
    ssize_t g = pwrite(l->fd, buf, len, (off_t)addr);
    return g == (ssize_t)len ? 0 : -1;
}

static int l_main_image(void *c, uint64_t *base, uint64_t *size) {
    lctx *l = (lctx *)c;
    char path[64], exe[512], line[1024];
    snprintf(path, sizeof path, "/proc/%d/exe", l->pid);
    ssize_t n = readlink(path, exe, sizeof exe - 1);
    if (n <= 0) return -1;
    exe[n] = 0;
    snprintf(path, sizeof path, "/proc/%d/maps", l->pid);
    FILE *f = fopen(path, "r");
    if (!f) return -1;
    unsigned long long lo = 0, hi = 0;
    int found = 0;
    while (fgets(line, sizeof line, f)) {
        unsigned long long s, e;
        if (sscanf(line, "%llx-%llx", &s, &e) != 2) continue;
        char *p = strchr(line, '/');
        if (!p) continue;
        p[strcspn(p, "\n")] = 0;
        if (strcmp(p, exe) != 0) continue;
        if (!found) lo = s;
        hi = e;
        found = 1;
    }
    fclose(f);
    if (!found) return -1;
    *base = lo;
    *size = hi - lo;
    return 0;
}

int ms_backend_open(ms_backend *be, int pid, char *err, size_t errn) {
    char path[64];
    snprintf(path, sizeof path, "/proc/%d/mem", pid);
    int fd = open(path, O_RDWR);
    if (fd < 0) { snprintf(err, errn, "開けませんでした"); return -1; }
    lctx *l = (lctx *)calloc(1, sizeof(lctx));
    l->fd = fd;
    l->pid = pid;
    be->ctx = l;
    be->regions = l_regions;
    be->read = l_read;
    be->write = l_write;
    be->main_image = l_main_image;
    return 0;
}

void ms_backend_close(ms_backend *be) {
    if (!be->ctx) return;
    lctx *l = (lctx *)be->ctx;
    close(l->fd);
    free(l);
    be->ctx = NULL;
}

#endif /* __linux__ */

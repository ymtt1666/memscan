/* iOS 用: Mach API で他プロセスのメモリを読み書きする */
#ifdef __APPLE__

#include "backend.h"
#include <stdlib.h>
#include <string.h>
#include <mach/mach.h>
#include <mach-o/loader.h>
#include <mach/task_info.h>

/* iOS SDK では mach_vm.h が使えないので、自分で宣言する */
extern kern_return_t mach_vm_region(vm_map_t, mach_vm_address_t *, mach_vm_size_t *, vm_region_flavor_t,
                                    vm_region_info_t, mach_msg_type_number_t *, mach_port_t *);
extern kern_return_t mach_vm_read_overwrite(vm_map_t, mach_vm_address_t, mach_vm_size_t,
                                            mach_vm_address_t, mach_vm_size_t *);
extern kern_return_t mach_vm_write(vm_map_t, mach_vm_address_t, vm_offset_t, mach_msg_type_number_t);
extern kern_return_t mach_vm_protect(vm_map_t, mach_vm_address_t, mach_vm_size_t, boolean_t, vm_prot_t);

typedef struct { task_t task; } mctx;

#define MAX_REGION_BYTES (1ULL << 30)

static int m_regions(void *c, ms_region **out, size_t *n) {
    mctx *m = (mctx *)c;
    size_t cap = 256, cnt = 0;
    ms_region *r = (ms_region *)malloc(cap * sizeof(ms_region));
    if (!r) return -1;
    mach_vm_address_t addr = 0;
    for (;;) {
        mach_vm_size_t size = 0;
        vm_region_basic_info_data_64_t info;
        mach_msg_type_number_t count = VM_REGION_BASIC_INFO_COUNT_64;
        mach_port_t obj = MACH_PORT_NULL;
        kern_return_t kr = mach_vm_region(m->task, &addr, &size, VM_REGION_BASIC_INFO_64,
                                          (vm_region_info_t)&info, &count, &obj);
        if (kr != KERN_SUCCESS) break;
        if ((info.protection & VM_PROT_READ) && (info.protection & VM_PROT_WRITE) &&
            !info.shared && size <= MAX_REGION_BYTES) {
            if (cnt == cap) {
                cap *= 2;
                ms_region *p = (ms_region *)realloc(r, cap * sizeof(ms_region));
                if (!p) { free(r); return -1; }
                r = p;
            }
            r[cnt].start = addr;
            r[cnt].size = size;
            cnt++;
        }
        addr += size;
    }
    *out = r;
    *n = cnt;
    return 0;
}

static int m_read(void *c, uint64_t addr, void *buf, size_t len) {
    mctx *m = (mctx *)c;
    mach_vm_size_t got = 0;
    kern_return_t kr = mach_vm_read_overwrite(m->task, addr, len, (mach_vm_address_t)(uintptr_t)buf, &got);
    return (kr == KERN_SUCCESS && got == len) ? 0 : -1;
}

static int m_write(void *c, uint64_t addr, const void *buf, size_t len) {
    mctx *m = (mctx *)c;
    kern_return_t kr = mach_vm_write(m->task, addr, (vm_offset_t)buf, (mach_msg_type_number_t)len);
    if (kr == KERN_SUCCESS) return 0;
    /* 書き込み禁止ページだった場合は、書けるようにしてからもう一度 */
    mach_vm_address_t pg = addr & ~(mach_vm_address_t)0x3FFF;
    mach_vm_size_t pl = ((addr + len + 0x3FFF) & ~(mach_vm_address_t)0x3FFF) - pg;
    mach_vm_protect(m->task, pg, pl, FALSE, VM_PROT_READ | VM_PROT_WRITE | VM_PROT_COPY);
    kr = mach_vm_write(m->task, addr, (vm_offset_t)buf, (mach_msg_type_number_t)len);
    return kr == KERN_SUCCESS ? 0 : -1;
}

/* 本体(メイン実行ファイル)の読み込み先と大きさ。保存したチートのアドレスを
 * 「本体の先頭からの位置」にするために使う。 */
static int m_main_image(void *c, uint64_t *base, uint64_t *size) {
    mctx *m = (mctx *)c;
    task_dyld_info_data_t di;
    mach_msg_type_number_t cnt = TASK_DYLD_INFO_COUNT;
    if (task_info(m->task, TASK_DYLD_INFO, (task_info_t)&di, &cnt) != KERN_SUCCESS) return -1;

    struct { uint32_t version; uint32_t count; uint64_t array; } hdr;
    if (m_read(c, di.all_image_info_addr, &hdr, sizeof(hdr)) != 0 || hdr.count == 0) return -1;
    struct { uint64_t load; uint64_t path; uint64_t mod; } first;
    if (m_read(c, hdr.array, &first, sizeof(first)) != 0) return -1;

    struct mach_header_64 mh;
    if (m_read(c, first.load, &mh, sizeof(mh)) != 0 || mh.magic != MH_MAGIC_64) return -1;
    if (mh.sizeofcmds == 0 || mh.sizeofcmds > (1u << 20)) return -1;
    uint8_t *cmds = (uint8_t *)malloc(mh.sizeofcmds);
    if (!cmds) return -1;
    if (m_read(c, first.load + sizeof(mh), cmds, mh.sizeofcmds) != 0) { free(cmds); return -1; }

    uint64_t text_vm = 0, end = 0;
    int have_text = 0;
    uint32_t off = 0;
    for (uint32_t i = 0; i < mh.ncmds && off + sizeof(struct load_command) <= mh.sizeofcmds; i++) {
        struct load_command *lc = (struct load_command *)(cmds + off);
        if (lc->cmdsize < sizeof(struct load_command) || off + lc->cmdsize > mh.sizeofcmds) break;
        if (lc->cmd == LC_SEGMENT_64) {
            struct segment_command_64 *sg = (struct segment_command_64 *)lc;
            if (strncmp(sg->segname, "__TEXT", 16) == 0) { text_vm = sg->vmaddr; have_text = 1; }
            if (sg->vmaddr > 0 && sg->vmaddr + sg->vmsize > end) end = sg->vmaddr + sg->vmsize;
        }
        off += lc->cmdsize;
    }
    free(cmds);
    if (!have_text || end <= text_vm) return -1;
    *base = first.load;
    *size = end - text_vm;
    return 0;
}

int ms_backend_open(ms_backend *be, int pid, char *err, size_t errn) {
    task_t task = MACH_PORT_NULL;
    kern_return_t kr = task_for_pid(mach_task_self(), pid, &task);
    if (kr != KERN_SUCCESS) {
        snprintf(err, errn, "接続できませんでした (task_for_pid=%d)。権限が足りない可能性があります", (int)kr);
        return -1;
    }
    mctx *m = (mctx *)calloc(1, sizeof(mctx));
    if (!m) { snprintf(err, errn, "メモリが足りません"); return -1; }
    m->task = task;
    be->ctx = m;
    be->regions = m_regions;
    be->read = m_read;
    be->write = m_write;
    be->main_image = m_main_image;
    return 0;
}

void ms_backend_close(ms_backend *be) {
    if (!be->ctx) return;
    mctx *m = (mctx *)be->ctx;
    mach_port_deallocate(mach_task_self(), m->task);
    free(m);
    be->ctx = NULL;
}

#endif /* __APPLE__ */

#include "engine.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <errno.h>

#define CHUNK (1u << 20)
#define PAGE  4096u

static const size_t WIDTH[MS_NTYPES] = {1, 2, 4, 8, 4, 8};
static const char *NAMES[MS_NTYPES] = {"i8", "i16", "i32", "i64", "f32", "f64"};

size_t ms_type_width(ms_type t) { return WIDTH[t]; }
const char *ms_type_name(ms_type t) { return NAMES[t]; }

int ms_type_parse(const char *s, ms_type *t) {
    for (int i = 0; i < MS_NTYPES; i++)
        if (s && strcmp(s, NAMES[i]) == 0) { *t = (ms_type)i; return 0; }
    return -1;
}

static void seterr(char *err, size_t n, const char *msg) {
    if (err && n) snprintf(err, n, "%s", msg);
}

void ms_init(ms_engine *e, ms_backend be) {
    memset(e, 0, sizeof(*e));
    e->be = be;
}

void ms_reset(ms_engine *e) {
    free(e->c);
    e->c = NULL;
    e->n = e->cap = 0;
    e->active = 0;
}

void ms_free(ms_engine *e) { ms_reset(e); }

/* ---------- 値の変換 ---------- */

int ms_parse(ms_type t, const char *s, uint64_t *raw) {
    if (!s) return -1;
    while (*s == ' ' || *s == '\t') s++;
    if (!*s) return -1;
    char *end = NULL;
    errno = 0;
    uint64_t r = 0;
    if (t == MS_F32 || t == MS_F64) {
        double d = strtod(s, &end);
        if (end == s || errno == ERANGE || isnan(d) || isinf(d)) return -1;
        while (*end == ' ' || *end == '\t') end++;
        if (*end) return -1;
        if (t == MS_F32) { float f = (float)d; memcpy(&r, &f, 4); }
        else memcpy(&r, &d, 8);
        *raw = r;
        return 0;
    }
    int neg = (*s == '-');
    if (neg) {
        long long v = strtoll(s, &end, 10);
        if (end == s || errno == ERANGE) return -1;
        while (*end == ' ' || *end == '\t') end++;
        if (*end) return -1;
        long long lo = (t == MS_I8) ? -128LL : (t == MS_I16) ? -32768LL
                     : (t == MS_I32) ? -2147483648LL : (-9223372036854775807LL - 1);
        if (v < lo) return -1;
        r = (uint64_t)v;
    } else {
        unsigned long long v = strtoull(s, &end, 10);
        if (end == s || errno == ERANGE) return -1;
        while (*end == ' ' || *end == '\t') end++;
        if (*end) return -1;
        unsigned long long hi = (t == MS_I8) ? 0xFFULL : (t == MS_I16) ? 0xFFFFULL
                              : (t == MS_I32) ? 0xFFFFFFFFULL : 0xFFFFFFFFFFFFFFFFULL;
        if (v > hi) return -1;
        r = v;
    }
    size_t w = WIDTH[t];
    if (w < 8) r &= ((1ULL << (w * 8)) - 1);
    *raw = r;
    return 0;
}

void ms_format(ms_type t, uint64_t raw, char *out, size_t n) {
    switch (t) {
    case MS_I8:  snprintf(out, n, "%d", (int)(int8_t)raw); break;
    case MS_I16: snprintf(out, n, "%d", (int)(int16_t)raw); break;
    case MS_I32: snprintf(out, n, "%d", (int)(int32_t)raw); break;
    case MS_I64: snprintf(out, n, "%lld", (long long)(int64_t)raw); break;
    case MS_F32: { float f; memcpy(&f, &raw, 4); snprintf(out, n, "%.6g", (double)f); break; }
    case MS_F64: { double d; memcpy(&d, &raw, 8); snprintf(out, n, "%.12g", d); break; }
    default: snprintf(out, n, "?");
    }
}

/* ---------- 比較 ---------- */

static int val_eq(ms_type t, uint64_t a, uint64_t b) {
    switch (t) {
    case MS_I8:  return (uint8_t)a == (uint8_t)b;
    case MS_I16: return (uint16_t)a == (uint16_t)b;
    case MS_I32: return (uint32_t)a == (uint32_t)b;
    case MS_I64: return a == b;
    case MS_F32: {
        float x, y; memcpy(&x, &a, 4); memcpy(&y, &b, 4);
        if (isnan(x) || isnan(y) || isinf(x) || isinf(y)) return 0;
        return fabsf(x - y) <= 1e-5f * fmaxf(1.0f, fabsf(y));
    }
    case MS_F64: {
        double x, y; memcpy(&x, &a, 8); memcpy(&y, &b, 8);
        if (isnan(x) || isnan(y) || isinf(x) || isinf(y)) return 0;
        return fabs(x - y) <= 1e-9 * fmax(1.0, fabs(y));
    }
    default: return 0;
    }
}

static int val_cmp(ms_type t, uint64_t a, uint64_t b) { /* -1,0,1 / 2 = 比べられない */
    switch (t) {
    case MS_I8:  { int8_t x = (int8_t)a, y = (int8_t)b; return x < y ? -1 : x > y; }
    case MS_I16: { int16_t x = (int16_t)a, y = (int16_t)b; return x < y ? -1 : x > y; }
    case MS_I32: { int32_t x = (int32_t)a, y = (int32_t)b; return x < y ? -1 : x > y; }
    case MS_I64: { int64_t x = (int64_t)a, y = (int64_t)b; return x < y ? -1 : x > y; }
    case MS_F32: {
        float x, y; memcpy(&x, &a, 4); memcpy(&y, &b, 4);
        if (isnan(x) || isnan(y)) return 2;
        return x < y ? -1 : x > y;
    }
    case MS_F64: {
        double x, y; memcpy(&x, &a, 8); memcpy(&y, &b, 8);
        if (isnan(x) || isnan(y)) return 2;
        return x < y ? -1 : x > y;
    }
    default: return 2;
    }
}

static uint64_t mask(ms_type t, uint64_t v) {
    size_t w = WIDTH[t];
    return w < 8 ? (v & ((1ULL << (w * 8)) - 1)) : v;
}

static int match_rel(ms_type t, ms_mode m, uint64_t cur, uint64_t old) {
    int c = val_cmp(t, cur, old);
    if (c == 2) return 0;
    switch (m) {
    case MS_INC:  return c > 0;
    case MS_DEC:  return c < 0;
    case MS_CHG:  return mask(t, cur) != mask(t, old);
    case MS_SAME: return mask(t, cur) == mask(t, old);
    default: return 0;
    }
}

/* ---------- 候補の保持 ---------- */

static int add_cand(ms_engine *e, uint64_t addr, uint64_t raw) {
    if (e->n >= MS_MAX_CANDS) return -1;
    if (e->n == e->cap) {
        size_t nc = e->cap ? e->cap * 2 : 4096;
        if (nc > MS_MAX_CANDS) nc = MS_MAX_CANDS;
        ms_cand *p = (ms_cand *)realloc(e->c, nc * sizeof(ms_cand));
        if (!p) return -1;
        e->c = p;
        e->cap = nc;
    }
    e->c[e->n].addr = addr;
    e->c[e->n].old = raw;
    e->n++;
    return 0;
}

static int scan_buf(ms_engine *e, ms_type t, uint64_t base, const uint8_t *buf, size_t len,
                    int known, uint64_t target) {
    size_t w = WIDTH[t];
    for (size_t off = 0; off + w <= len; off += w) {
        uint64_t v = 0;
        memcpy(&v, buf + off, w);
        if (known && !val_eq(t, v, target)) continue;
        if (add_cand(e, base + off, v) != 0) return -1;
    }
    return 0;
}

int ms_first(ms_engine *e, ms_type t, const char *value, char *err, size_t errn) {
    uint64_t target = 0;
    int known = (value != NULL);
    if (known && ms_parse(t, value, &target) != 0) {
        seterr(err, errn, "数値を正しく入力してください");
        return -1;
    }
    ms_reset(e);
    e->type = t;

    ms_region *rg = NULL;
    size_t nr = 0;
    if (e->be.regions(e->be.ctx, &rg, &nr) != 0 || nr == 0) {
        free(rg);
        seterr(err, errn, "ゲームのメモリを読めませんでした");
        return -1;
    }
    size_t w = WIDTH[t];
    if (!known) {
        uint64_t total = 0;
        for (size_t i = 0; i < nr; i++) total += rg[i].size / w;
        if (total > MS_MAX_CANDS) {
            free(rg);
            seterr(err, errn, "範囲が大きすぎます。数値がわかる項目で検索してください");
            return -1;
        }
    }
    uint8_t *buf = (uint8_t *)malloc(CHUNK);
    if (!buf) { free(rg); seterr(err, errn, "メモリが足りません"); return -1; }

    int rc = 0;
    for (size_t i = 0; i < nr && rc == 0; i++) {
        for (uint64_t off = 0; off < rg[i].size && rc == 0; off += CHUNK) {
            size_t len = (size_t)((rg[i].size - off) < CHUNK ? (rg[i].size - off) : CHUNK);
            uint64_t a = rg[i].start + off;
            if (e->be.read(e->be.ctx, a, buf, len) == 0) {
                rc = scan_buf(e, t, a, buf, len, known, target);
            } else {
                /* 読めないページが混ざっている。ページ単位で試す */
                for (size_t p = 0; p < len && rc == 0; p += PAGE) {
                    size_t pl = (len - p) < PAGE ? (len - p) : PAGE;
                    if (e->be.read(e->be.ctx, a + p, buf, pl) == 0)
                        rc = scan_buf(e, t, a + p, buf, pl, known, target);
                }
            }
        }
    }
    free(buf);
    free(rg);
    if (rc != 0) {
        ms_reset(e);
        seterr(err, errn, "候補が多すぎます。別の数値で検索してください");
        return -1;
    }
    e->active = 1;
    return 0;
}

typedef struct { uint64_t base; int ok; uint8_t page[PAGE]; } pcache;

static int cached_read(ms_engine *e, pcache *pc, uint64_t addr, size_t w, uint64_t *raw) {
    uint64_t base = addr & ~(uint64_t)(PAGE - 1);
    if (pc->base != base) {
        pc->base = base;
        pc->ok = (e->be.read(e->be.ctx, base, pc->page, PAGE) == 0);
    }
    uint64_t v = 0;
    if (pc->ok && addr + w <= base + PAGE) {
        memcpy(&v, pc->page + (addr - base), w);
        *raw = v;
        return 0;
    }
    if (e->be.read(e->be.ctx, addr, &v, w) == 0) { *raw = v; return 0; }
    return -1;
}

int ms_next(ms_engine *e, ms_mode m, const char *value, char *err, size_t errn) {
    if (!e->active) { seterr(err, errn, "先に検索してください"); return -1; }
    uint64_t target = 0;
    if (m == MS_EQ && ms_parse(e->type, value, &target) != 0) {
        seterr(err, errn, "数値を正しく入力してください");
        return -1;
    }
    pcache *pc = (pcache *)malloc(sizeof(pcache));
    if (!pc) { seterr(err, errn, "メモリが足りません"); return -1; }
    pc->base = ~(uint64_t)0;
    pc->ok = 0;
    size_t w = WIDTH[e->type], j = 0;
    for (size_t i = 0; i < e->n; i++) {
        uint64_t cur;
        if (cached_read(e, pc, e->c[i].addr, w, &cur) != 0) continue;
        int hit = (m == MS_EQ) ? val_eq(e->type, cur, target) : match_rel(e->type, m, cur, e->c[i].old);
        if (hit) {
            e->c[j].addr = e->c[i].addr;
            e->c[j].old = cur;
            j++;
        }
    }
    e->n = j;
    free(pc);
    return 0;
}

int ms_get_result(ms_engine *e, size_t idx, uint64_t *addr, uint64_t *cur, uint64_t *old) {
    if (idx >= e->n) return -1;
    *addr = e->c[idx].addr;
    *old = e->c[idx].old;
    uint64_t v = 0;
    if (ms_read_value(e, *addr, e->type, &v) != 0) { *cur = 0; return 1; }
    *cur = v;
    return 0;
}

/* ---------- 読み書き ---------- */

int ms_read_value(ms_engine *e, uint64_t addr, ms_type t, uint64_t *raw) {
    uint64_t v = 0;
    if (e->be.read(e->be.ctx, addr, &v, WIDTH[t]) != 0) return -1;
    *raw = v;
    return 0;
}

int ms_write_value(ms_engine *e, uint64_t addr, ms_type t, uint64_t raw, int record_undo) {
    size_t w = WIDTH[t];
    uint64_t oldv = 0;
    int have_old = (e->be.read(e->be.ctx, addr, &oldv, w) == 0);
    if (e->be.write(e->be.ctx, addr, &raw, w) != 0) return -1;
    if (record_undo && have_old) {
        if (e->nundo == MS_MAX_UNDO) {
            memmove(&e->undo[0], &e->undo[1], (MS_MAX_UNDO - 1) * sizeof(ms_undo_ent));
            e->nundo--;
        }
        ms_undo_ent *u = &e->undo[e->nundo++];
        u->addr = addr;
        u->len = (uint8_t)w;
        memcpy(u->bytes, &oldv, w);
    }
    return 0;
}

int ms_undo(ms_engine *e) {
    if (e->nundo == 0) return -1;
    ms_undo_ent *u = &e->undo[e->nundo - 1];
    int rc = e->be.write(e->be.ctx, u->addr, u->bytes, u->len);
    if (rc == 0) e->nundo--;
    return rc == 0 ? 0 : -1;
}

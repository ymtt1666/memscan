#ifndef MS_ENGINE_H
#define MS_ENGINE_H

#include <stdint.h>
#include <stddef.h>

#define MS_MAX_CANDS 6000000u
#define MS_MAX_UNDO  256

typedef enum { MS_I8, MS_I16, MS_I32, MS_I64, MS_F32, MS_F64, MS_NTYPES } ms_type;
typedef enum { MS_EQ, MS_INC, MS_DEC, MS_CHG, MS_SAME } ms_mode;

typedef struct { uint64_t start, size; } ms_region;

/* 対象プロセスのメモリにアクセスするための差し替え部品。
 * iOS では Mach API、テストでは Linux の /proc を使う。 */
typedef struct {
    void *ctx;
    int (*regions)(void *ctx, ms_region **out, size_t *n); /* *out は呼び出し側が free */
    int (*read)(void *ctx, uint64_t addr, void *buf, size_t len);        /* 0 = 成功 */
    int (*write)(void *ctx, uint64_t addr, const void *buf, size_t len); /* 0 = 成功 */
    int (*main_image)(void *ctx, uint64_t *base, uint64_t *size);        /* 0 = 成功 */
} ms_backend;

typedef struct { uint64_t addr; uint64_t old; } ms_cand;
typedef struct { uint64_t addr; uint8_t len; uint8_t bytes[8]; } ms_undo_ent;

typedef struct {
    ms_backend be;
    ms_type type;
    int active;              /* 検索結果があるか */
    ms_cand *c;
    size_t n, cap;
    ms_undo_ent undo[MS_MAX_UNDO];
    size_t nundo;
} ms_engine;

void        ms_init(ms_engine *e, ms_backend be);
void        ms_reset(ms_engine *e);
void        ms_free(ms_engine *e);

size_t      ms_type_width(ms_type t);
int         ms_type_parse(const char *s, ms_type *t);
const char *ms_type_name(ms_type t);
int         ms_parse(ms_type t, const char *s, uint64_t *raw);
void        ms_format(ms_type t, uint64_t raw, char *out, size_t n);

/* value == NULL で「不明な初期値」検索。戻り値 0=成功, -1=失敗(errに理由) */
int ms_first(ms_engine *e, ms_type t, const char *value, char *err, size_t errn);
int ms_next(ms_engine *e, ms_mode m, const char *value, char *err, size_t errn);

/* 0=成功, -1=範囲外, 1=読めない(curは無効) */
int ms_get_result(ms_engine *e, size_t idx, uint64_t *addr, uint64_t *cur, uint64_t *old);

int ms_read_value(ms_engine *e, uint64_t addr, ms_type t, uint64_t *raw);
int ms_write_value(ms_engine *e, uint64_t addr, ms_type t, uint64_t raw, int record_undo);
int ms_undo(ms_engine *e);

#endif
